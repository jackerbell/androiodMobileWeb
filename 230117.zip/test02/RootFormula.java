package test02;

import java.util.Scanner;

public class RootFormula {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true){

            // 1. 입력단 방정식의 계수 a,b,c 입력
            System.out.printf("계수 a : ");
            int a = scanner.nextInt();
            System.out.printf("계수 b : ");
            int b = scanner.nextInt();
            System.out.printf("계수 c : ");
            int c = scanner.nextInt();


            // ------------------- 로직(답안) 시작--------------------------------------------------//
            // 2. 방정식 연산
            double root1 = (-b+Math.sqrt((Math.pow(b,2)-4*a*c)))/(2*a); // 근의 공식 plus part
            double root2 = (-b-Math.sqrt((Math.pow(b,2)-4*a*c)))/(2*a); // 근의 공식 minus part

            // 3. case 별로 나누기
            //case 두 개의 서로 다른 실근 , 중근(두개의 값이 같을 경우), 둘 중 하나 허수, 근이 없는 경우
            boolean case1 = (root1 == root2) && !Double.isNaN(root1) && !Double.isNaN(root2); // 둘 다 실근이고 중근인 경우
            boolean case2 = (root1 != root2) && !Double.isNaN(root1) && !Double.isNaN(root2); // 서로 다른 두 실근인 경우
            boolean case3 = !Double.isNaN(root1) && Double.isNaN(root2); // root1이 실근 root2가 허근인경우
            boolean case4 = Double.isNaN(root1) && !Double.isNaN(root2); // root1이 허근 root2가 실근인 경우

            System.out.println("=".repeat(50));
            // 4. 조건문으로 분기 구현
            if(case1) { // case1  둘 다 실근이고 중근인 경우
                System.out.println("실근이 1 개 있습니다.");
                System.out.println("=".repeat(50));
                System.out.printf("실근 : %.6f\n",root1);
            } else if(case2) {  // case 2 서로 다른 두 실근인 경우 여기서 조건 분기
                System.out.println("실근이 2 개 있습니다."); // 공통 사항이므로 따로 빼서 처리
                System.out.println("=".repeat(50));

                if(root1 >= 0 && root2 >= 0) { // case 2-1 서로 다른 두 양의 실근일 경우
                    System.out.printf("양의 실근 : %.6f\n",root1);
                    System.out.printf("양의 실근 : %.6f\n",root2);
                } else if (root1 * root2 <= 0 ) { // case 2-2 둘 중 하나가 음수일 경우 무조건 0 이하(양수의 범위가 0이상이므로)가 됨

                    if(root1 >= 0 && root2 < 0){ // case 2-2-1 root1이 양의 실근이고 root2가 음의 실근인 경우
                        System.out.printf("양의 실근 : %.6f\n",root1);
                        System.out.printf("음의 실근 : %.6f\n",root2);
                    } else if (root1 < 0 && root2 >= 0) { // case 2-2-2 root1이 음의 실근이고 root2가 양의 실근인 경우
                        System.out.printf("양의 실근 : %.6f\n",root2);
                        System.out.printf("음의 실근 : %.6f\n",root1);
                    }

                } else if (root1 < 0 && root2 < 0) { // case 2-3 root1,root2 둘 다 음의 실근인 경우
                    System.out.printf("음의 실근 : %.6f\n",root1);
                    System.out.printf("음의 실근 : %.6f\n",root2);
                }

            } else if(case3) {  // case 3 root1이 실근 root2가 허근인경우
                System.out.println("실근이 1개 있습니다.");
                System.out.println("=".repeat(50));
                System.out.printf("실근 : %.6f",root1);
            } else if (case4) { // case 4 root1이 허근 root2가 실근인 경우
                System.out.println("실근이 1개 있습니다.");
                System.out.println("=".repeat(50));
                System.out.printf("실근 : %.6f",root2);
            } else { // case 5 위의 요소 중 그 어떤 조건에도 해당하지 않을 경우 근을 허수로 판별
                System.out.println("허근입니다.");
            }
            System.out.println("=".repeat(50)); // 구분선
            // ------------------- 로직(답안) 끝--------------------------------------------------//

            //5. 진행 여부 결정
            scanner.nextLine();
            System.out.printf("계속할까요? (y/n) ");
            String exit = scanner.nextLine();

            if(!exit.equals("y")){
                break;
            }
            System.out.println();
        }
    }
}
