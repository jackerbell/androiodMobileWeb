package com.kjh.mfp.maple.components;

public enum Job {
    MAGICIAN("마법사"), // Job 타입의 객체, 정적..상시 유지 안에 인자는 생성자 로
    THIEF("도적"),
    WARRIOR("전사"),
    BOWMAN("궁수"),
    PIRATE("해적");

    public final String korean;;

    Job(String korean) {
        this.korean = korean;
    }
}
