package com.kjh.mfp.maple.components;

import com.kjh.mfp.maple.components.props.Ridable;

public class Player {
    // 문자열 타입의 name 멤버 변수 만들고 캡슐화
    private String name;
    private Job job;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public void ride(Ridable ridable){
        Mob mob = (Mob) ridable;
        System.out.println(this.getName() + "이/가 " + mob.getName() + "에 탑승했다.");
    }
}
