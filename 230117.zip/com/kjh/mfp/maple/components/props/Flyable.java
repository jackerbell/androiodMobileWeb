package com.kjh.mfp.maple.components.props;

public interface Flyable {
    void fly();
}
