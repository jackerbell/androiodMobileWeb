package com.kjh.mfp.maple;

import com.kjh.mfp.maple.components.Job;
import com.kjh.mfp.maple.components.Mob;
import com.kjh.mfp.maple.components.MonsterBall;
import com.kjh.mfp.maple.components.Player;
import com.kjh.mfp.maple.components.mobs.OrangeMushroom;
import com.kjh.mfp.maple.components.mobs.RedSnail;
import com.kjh.mfp.maple.components.mobs.Wyvern;
import com.kjh.mfp.maple.components.props.Flyable;
import com.kjh.mfp.maple.components.props.Ridable;

import java.sql.SQLOutput;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    /*
    *  몹 이름은 완성 한글 1자 이상 10자 이하로만 만들기..
    *
    * */
    public static void main(String[] args) {


        Triplet<String,String,String> slowpoke_EVTree = new Triplet<>();
        slowpoke_EVTree.setValueA("야돈");
        slowpoke_EVTree.setValueB("야도란");
        slowpoke_EVTree.setValueC("야도킹");
        System.out.printf("%s의 진화트리는 순서대로 %s(25레벨에 진화) → %s(왕의 징표석을 가지고 통신교환) → %s",slowpoke_EVTree.getValueA(),slowpoke_EVTree.getValueA(),slowpoke_EVTree.getValueB(),slowpoke_EVTree.getValueC());

        Triplet<String,String,Long> nationalInfo = new Triplet<>();
        nationalInfo.setValueA("대한민국");
        nationalInfo.setValueB("서울");
        nationalInfo.setValueC(20000000L);

















        // 학생의 이름 - 성적 : String - Integer
        // 지역의 한국어 이름 - 영어 이름 : String - String
        // 가게의 이름 - 오픈 여부 : String - Boolean

//        Tuple<String, Double> studentScore = new Tuple<>();
//         studentScore.setValueA("김학생"); // CTRL P 누르면 무슨 인자 집어넣는지 나옴..
//         studentScore.setValueB(58.7);
//        System.out.printf("%s 학생의 평균은 %.1f점입니다.\n",studentScore.getValueA(),studentScore.getValueB());
//
//         Tuple<String, String> regionName = new Tuple<>();
//         regionName.setValueA("대구");
//         regionName.setValueA("Daegu");
//        System.out.printf("%s(%s) 지역의 여름철 평균 기온...\n",regionName.getValueA(),regionName.getValueB());
//
//         Tuple<String,Boolean> isStoreOpened = new Tuple<>();
//         isStoreOpened.setValueA("맥도날드");
//         isStoreOpened.setValueB(false);
//        System.out.printf("%s는 현재 %s있습니다.\n",isStoreOpened.getValueA(),isStoreOpened.getValueB()?"열려":"닫혀");
//

















//        OrangeMushroom orangeMushroom = new OrangeMushroom();
//        RedSnail redSnail = new RedSnail();
//        Wyvern wyvern = new Wyvern();
//
//        MonsterBall<Wyvern> wyvernMonsterBall = new MonsterBall<>(); // 특정 몬스터만 따로 담기 위해 설정(와이번) 혹은 탑승가능여부.. 비행가능여부..
////        wyvernMonsterBall.setMonster(orangeMushroom);
////        wyvernMonsterBall.setMonster(redSnail);
//        wyvernMonsterBall.setMonster(wyvern);
//
//        MonsterBall<Wyvern> ball1 = new MonsterBall<>();
//        ball1.setMonster(wyvern);
//        MonsterBall<OrangeMushroom> ball2 = new MonsterBall<>();
//        ball2.setMonster(orangeMushroom);
//        System.out.println("ball1과 ball2는 같은 몬스터인가.");
//        System.out.println(ball1.hasSM(ball2));

//        MonsterBall<String> mbs = new MonsterBall<>(); // 잘못된 예시.. T extends Java
//        mbs.setMonster("zz");

//        Wyvern wyvern = new Wyvern();
//        Player player = new Player();
//        player.setName("antiPlayer");
//        player.ride(wyvern);


//        Mob[] mobs = {
//                new OrangeMushroom(),
//                new RedSnail(),
//                new Wyvern()
//        };
//
//        System.out.println("=".repeat(50));
//        for (Mob mob: mobs) {
//            if(mob instanceof Flyable){
//                System.out.println(mob.getName()+"는 날수 있다.");
//            }else{
//                System.out.println(mob.getName()+"는 날수 없다.");
//            }
//
//            System.out.println("=".repeat(50));
//
//            if(mob instanceof Ridable){
//                System.out.println(mob.getName()+"는 탈수 있다.");
//            }else{
//                System.out.println(mob.getName()+"는 탈수 없다.");
//            }
//
//
//        }



//        Wyvern wyvern = new Wyvern();
//        Flyable flyable = wyvern;
//        flyable.fly();










//        Player player = new Player();
//        player.setName("zz궁수zz");
////        player.setJob(Job.PIRATE);
////        player.setJob(Job.BOWMAN);
//        player.setJob(Job.MAGICIAN);
//        player.setJob(Job.THIEF);
//        player.setJob(Job.WARRIOR);
////        player.setJob(Job.전사); // 열거형으로 지정한 Job타입의 객체만 지정할 수 있음!!!!!
//
//
//        Player player2 = new Player();
//        player2.setName("zl랄");
//        player2.setJob(Job.MAGICIAN);
//
//        System.out.println(player.getJob().korean);
//
//        OrangeMushroom orangeMushroom = new OrangeMushroom();
//        player.equals(null);
//        orangeMushroom.equals(null);
//        player.getJob().equals(null);// object를 상속받기에 가능

//        player.getJob().korean = "법사"; . final로 선언하므로 할당은 안됨!





//        Mob m = new Mob("주황버섯");
//        OrangeMushroom om1 = new OrangeMushroom(); // 접근 제한자 public
//        OrangeMushroom o =(OrangeMushroom) om1;
//        o.beCute();
//        RedSnail rs1 = new RedSnail();
////        Mob m = new RedSnail(); // 가능 Mob(부모) 객체의 변수..
//
//        o.attack(rs1);

//          Connection connection = new Connection();
////          try (connection) {
////              String message = "잘 실행함";
////              System.out.println(message);
////          }catch (NullPointerException ex){
////              System.out.println("NPE 오류 터짐");
////          }
//         try (connection) {
//              System.out.println("작업 시작");
//              String message = null;
//              System.out.println(message.length());
//              String message2 = "O1O";
//              System.out.println(Integer.parseInt(message2));
//          }catch (NullPointerException ex){
//              System.out.println("NPE 오류 터짐");
//          } catch (NumberFormatException ex) {
//              System.out.println("NFE 오류 터짐");
//          } finally {
//              System.out.println("작업 종료");
//         }
//
//
////        try{
////            String s = null;
////            s.length();
//////            int i = Integer.parseInt(s);
////        }catch (NumberFormatException ex){ // 선행 오류는 후행 오류보다 자식이어야 한다..
//            System.out.println("올바른 숫자가 아니다.");
//        }catch (NullPointerException ex){
//            System.out.println("무슨 오류인지 모르겟다. ");
//        }catch (Exception ex){
//            System.out.println("무슨 일인지 모르겠다.");
//        }

//        OrangeMushroom om = new OrangeMushroom();
//
//        try{
//            om.attack(om);
//            System.out.println("공격 성공");
//        }catch (Exception ex){
//            System.out.println("??");
//            System.out.println(ex.getMessage()); // 예외처리 메세지 띄우는법
//        }
//        RedSnail rs = new RedSnail();
////        om.move();
////        rs.move();
//
//        Mob[] mobs = {om,rs}; // Mob 클래스 객체화..
//        for (Mob mob: mobs
//             ) {
//            mob.move();
//        }

//        OrangeMushroom om = new OrangeMushroom();
//        om.attack(om);

//        Scanner scanner = new Scanner(System.in);
//        while (true){
//            System.out.print("정수를 입력하세요: ");
//            int n;
//            try{
//                n = scanner.nextInt();
//            }catch (InputMismatchException ex){
//                System.out.println("올바른 정수를 입력해주세요.");
//                continue;
//            }finally {
//                System.out.println("finally 실행됨");
//                scanner.nextLine(); //엔터를 누를 시 계속 예외처리됨으로 이를 방지하기 위해서 선언됨.
//            }
//            double sqrt = Math.sqrt(n);
//            System.out.printf("제곱근은 %f입니다.\n",sqrt);
//
//            scanner.nextLine();
//            System.out.print("계속할까요? (y/n)");
//            String exit = scanner.nextLine();
//            if(!exit.equals("y")){
//                break;
//            }
//        }





//        Mob blueSnail = new Mob("빨간달팽이");
//        blueSnail.name = "BLUE 스네일";
////        blueSnail.setName("BLUE 스네일");
//        blueSnail.sayHello();

//        Mob unknown = new Mob();
//        unknown.sayHello();
//
//        Mob redSnail = new Mob("빨간 달패이");
//        redSnail.sayHello();
//
//        Mob blueSnail = new Mob("블루 스네일");
//
//        Mob orangeMushroom = new Mob("주황버섯"); // 생성자 메서드 호출.. Mob(class Mob) new
//        orangeMushroom.sayHello();
        // Mob(public Mob)

//        Parent p = new Child();
//        p.doSomeThing(); //child 클래스 부가 실행됨..
//
//        Child p2 = new Child();
//        p2.doSomethingParent();
    }
}

//final class Parent{
//     void doSomeThing(){
//        System.out.println("부모가 뭔가 했다.");
//    }
//}
//
//class Child extends Parent{  // 부모에서 final로 선언할 경우 상속받을 수 없음 .. 코드 내에서 최종이기 때문에..
//    @Override
//    void doSomeThing(){
//        System.out.println("자식이 뭔가 했다.");
//    }
//
//    void doSomethingParent(){
//        super.doSomeThing();
//    }
//}


class Tuple<TA,TB> {
    private TA valueA;

    public TA getValueA() {
        return valueA;
    }

    public void setValueA(TA valueA) {
        this.valueA = valueA;
    }

    public TB getValueB() {
        return valueB;
    }

    public void setValueB(TB valueB) {
        this.valueB = valueB;
    }

    private TB valueB;

}

class Triplet<TA,TB,TC>{
    private TA valueA;
    private TB valueB;

    public TA getValueA() {
        return valueA;
    }

    public void setValueA(TA valueA) {
        this.valueA = valueA;
    }

    public TB getValueB() {
        return valueB;
    }

    public void setValueB(TB valueB) {
        this.valueB = valueB;
    }

    public TC getValueC() {
        return valueC;
    }

    public void setValueC(TC valueC) {
        this.valueC = valueC;
    }

    private TC valueC;
}

class Connection implements AutoCloseable {

    @Override
    public void close(){
        System.out.println("커넥션 객체의 연결이 끊어졌다.");
    }
}

class Cube extends Triplet<Integer,Integer,Integer>{
    public Cube(Integer a,Integer b,Integer c) {
        super.setValueA(a);
        super.setValueB(b);
        super.setValueC(c);
    }
    public int getVolume(){
        return this.getValueA()*this.getValueB()*this.getValueC();
    }
}