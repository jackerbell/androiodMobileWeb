package NadoCoding.chap11;

public class _03_Throw {
    public static void main(String[] args) {
        int age = 17;
        try {
            if(age<19){
//                System.out.println("만 19세 미만에게는 판매하지 않습니다.");
                throw new Exception("만 19세 미만에게는 판매하지 않습니다."); // 입력한 문장을 출력하는 예외를 발생시킴
            } else {
                System.out.println("주문하신 상품 여기 있습니다.");
            }
        } catch (Exception e){ // 여기서 받아서 처리
            e.printStackTrace();
        }
    }
}
