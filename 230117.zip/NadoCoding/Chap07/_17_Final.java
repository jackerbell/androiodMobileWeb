package NadoCoding.Chap07;

import NadoCoding.Chap07.camera.ActionCam;
import NadoCoding.Chap07.camera.SlowActionCam;

public class _17_Final {
    public static void main(String[] args) {
        ActionCam actionCam = new ActionCam();
//        actionCam.lens = "표준렌즈";
        actionCam.recordVideo();
        actionCam.makeVideo();

        System.out.println("-".repeat(20));

        SlowActionCam slowActionCam = new SlowActionCam();
        slowActionCam.recordVideo();
        slowActionCam.makeVideo();

    }
}
