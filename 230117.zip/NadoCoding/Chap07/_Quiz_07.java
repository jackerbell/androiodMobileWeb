package NadoCoding.Chap07;


// 버거 종류 3가지 햄,치즈,새우
// 각 버거 클래스로 생성
// 버거 이름을 담기 위한 name 변수 정의
// 재료 정보를 표시하는 cock 메소드 정의
// 공통 부분은 상속 및 메소드 오버라이딩으로 처리
// 햄버거 - 양상추,패티,피클  치즈버거 - 양상추,패티,피클,치즈  새우버거 - 양상추,패티,피클,새우

public class _Quiz_07 {
    public static void main(String[] args) {
        Hamburger[] hamburgers = new Hamburger[3];
        hamburgers[0] = new Hamburger();
        hamburgers[1] = new CheeseBurger();
        hamburgers[2] = new ShrimpBurger();

        System.out.println("주문하신 메뉴를 만듭니다.");
        System.out.println("-".repeat(25)+"주문 수령"+"-".repeat(25));
        for (Hamburger hamburger : hamburgers) {
            hamburger.cock();
            System.out.println("-".repeat(25)+"조리 중"+"-".repeat(25));
            System.out.println("요리가 완성되었습니다! 카운터로 와서 수령하세요!!");
            System.out.println("");
        }
    }
}

class Hamburger {
    String name;
    String[] ingredients = new String[] {"양상추","패티","피클"};
    public Hamburger(){
        this("햄버거");
    }
    public Hamburger(String name) {
        this.name = name;
    }

    public void cock(){
        System.out.println(this.name + "의 조리를 시작합니다!! 재료는 아래와 같습니다.");
        for (String ingredient : ingredients) {
            System.out.println(ingredient);
        }
    }
}

class CheeseBurger extends Hamburger {
    public CheeseBurger() {
        super("치즈버거");
    }

    @Override
    public void cock() {
        super.cock();
        System.out.println("치즈");
    }
}

class ShrimpBurger extends Hamburger {
    public ShrimpBurger() {
        super("새우버거");
    }

    @Override
    public void cock() {
        super.cock();
        System.out.println("새우");
    }
}
