package NadoCoding.Chap07;

public class _01_Class {
    BlackBox bbox = new BlackBox();
    BlackBox bbox2 = new BlackBox();

}
