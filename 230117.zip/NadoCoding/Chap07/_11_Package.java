package NadoCoding.Chap07;

import java.util.Random;

public class _11_Package {
    // 패키지.. 경로
    public static void main(String[] args) {
        Random random = new Random();
        System.out.println("랜덤 정수 : "+ random.nextInt(100)); // int의 범위 내에서 정수형 값 반환
        System.out.println("랜덤 실수 : "+random.nextDouble());
    }

}
