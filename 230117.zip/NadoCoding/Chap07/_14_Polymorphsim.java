package NadoCoding.Chap07;

import NadoCoding.Chap07.camera.Camera;
import NadoCoding.Chap07.camera.FactoryCam;
import NadoCoding.Chap07.camera.SpeedCam;

public class _14_Polymorphsim {
    // 다형성
    public static void main(String[] args) {
        // class Person 사람
        // class Student extends Person : 학생(학생은 사람이다. Student is person.)
        // class Teacher extends Person : 선생님(선생님은 사람이다. Teacher is person.)

        Camera camera = new Camera();
        Camera factoryCam = new FactoryCam();
        Camera speedCam = new SpeedCam();

        camera.showNameFeature();
        factoryCam.showNameFeature();
        speedCam.showNameFeature();

        System.out.println("-".repeat(10));
        Camera[] cameras = new Camera[3];
        cameras[0] = new Camera();
        cameras[1] = new FactoryCam();
        cameras[2] = new SpeedCam();

        for (Camera cam : cameras) {
            cam.showNameFeature();
        }

        System.out.println("-".repeat(10));

        if (camera instanceof Camera) {
            System.out.println("카메라입니다.");
        }

        if (factoryCam instanceof FactoryCam) {
            ((FactoryCam) factoryCam).detectFire();
        }

        if (speedCam instanceof SpeedCam) {
            ((SpeedCam) speedCam).checkSpeed();
            ((SpeedCam) speedCam).recognizeLicensePlate();
        }

        Object[] objs = new Object[3];
        objs[0] = new Camera();
        objs[1] = new FactoryCam();
        objs[2] = new SpeedCam();
    }
}
