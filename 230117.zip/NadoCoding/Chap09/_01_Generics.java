package NadoCoding.Chap09;

public class _01_Generics {
    public static void main(String[] args) {
        // 제네릭스
        int[] arrays = {1,2,3,4,5};
        double[] dArrays = {1.0,2.0,3.0,4.0,5.0};
        String[] strings = {"A","B","C","D","E"};

    }
}
