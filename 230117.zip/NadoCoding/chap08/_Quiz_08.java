package NadoCoding.chap08;

import NadoCoding.chap08.camera.SpeedCam;
import NadoCoding.chap08.detector.AccidentDetector;
import NadoCoding.chap08.reporter.VideoReporter;

public class _Quiz_08  {
    // speedCam 클래스 detect(),report()개선
    // 교통사고 감지하는 AccidentDetector 클래스 신규 생성
    // 신고 기능은 기존에 작성된 VideoReporter 클래스 활용
    // 모든 클래스는 적절한 위치에 정의

    public static void main(String[] args) {
        SpeedCam speedCam = new SpeedCam();
        speedCam.setDetectable(new AccidentDetector());
        speedCam.setReportable(new VideoReporter());
        speedCam.detect();
        speedCam.report();
    }

}
