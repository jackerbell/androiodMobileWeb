package NadoCoding.chap08;

//import NadoCoding.Chap07.BlackBoxRefurbish;
import NadoCoding.Chap07.*;
import NadoCoding.Chap07._10_AccessModifier;

public class _00_AccessModifierTest{
    public static void main(String[] args) {
        BlackBoxRefurbish b1 = new BlackBoxRefurbish();
        b1.modelName = "까망이"; // public
        // b1.resolution = "FHD"; // default 호출 안됨 패키지 경로가 다르므로
        // b1.price = 200000; // private 호출 안됨 다른 클래스에 존재..
//        b1.color = "블랙"; // protected 상속받지 않았고 패키지 경로가 다르기 때문에
    }
}
