public class test {
    public static void main(String[] args) {
        System.out.println(getOdd(3,2));
        System.out.println(getOdd(2,9));
        System.out.println(getOdd(4,2));
        System.out.println(getOdd(0,7));
        System.out.println(getOdd(-3,-4));
    }
    public static int getOdd(int a,int b){
        int result = 0; // 조건부에 따라 값을 할당받아 반환할 값
        if((a%2 == 1 && b%2==1)||(a%2 == 0 && b%2 == 0)){ // a,b 모두가 짝수이거나 모두 음수인 경우 result에 -1 할당
            result = -1;
        } else if (a*b == 0 || ( a<0 || b<0 )) { // a,b 둘 중 하나가 0이거나 하나 이상의 음수가 있을 경우 result에 -1 할당
            result = -1;
        } else if (a%2 == 1 && b%2 == 0) { // a가 홀수이고 b가 짝수일 때, result에 a값 할당
            result = a;
        } else if (b%2 == 1 && a%2 == 0) { // b가 홀수이고 a가 짝수일 때, result에 b값 할당
            result = b;
        }
        return result; // 결과값 반환..
    }
}

