package javajungsuk3;

import java.util.Scanner;

public class ForPractice {
    public static void main(String[] args) {
        int[] coinUnit = {500, 100, 50, 10};
        int money = 2680;
        System.out.println("money="+money);
        for(int i=0;i<coinUnit.length;i++) {
            int change500 = money/coinUnit[0];
            int change100 = (money-coinUnit[0]*change500)/coinUnit[1];
            int change50 = (money-coinUnit[0]*change500-coinUnit[1]*change100)/coinUnit[2];
            int change10 = (money-coinUnit[0]*change500-coinUnit[1]*change100-coinUnit[2]*change50)/coinUnit[3];
            if(i== coinUnit.length-1){
                System.out.printf("500원: %d\n100원: %d\n50원: %d\n10원: %d",change500,change100,change50,change10);
            }
        }
    }
}
