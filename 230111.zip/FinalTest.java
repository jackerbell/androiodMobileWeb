public class FinalTest {
    public static void main(String[] args) {
        System.out.println(getPrimeCount(new int[] {2,3,4,5,6}));
        System.out.println(getPrimeCount(new int[] {2,4,6,8,10}));
        System.out.println(getPrimeCount(new int[] {3,5,7,9,11}));
    }
    public static int getPrimeCount(int[] numbers){
        int count = 0; // 소수 개수 초기화
//
        for(int i = 0 ; i < numbers.length ; i++){
            boolean isPrime = true; // 소수인지 여부
            for(int j = 2 ; j <= numbers[i]/2 ; j++){ /*
                                                자신을 제외했을 때 1 이외에 나누어서 떨어지는 약수가 있으면 그 수의 2배수 역시 약수가 아니므로
                                                주어진 배열인자를 2로 나누어서 연산하더라도 결과는 동일
                                                ex) 37 => 18,36(18x2)은 약수X , 41 => 20,40(20x2)은 약수X
                                              */
                if(numbers[i]%j == 0){
                    isPrime = false;
                    break; // 1이외에 약수가 있으므로 false로 재할당 및 여기서 종료
                }
            }
            if(isPrime){ // 1이외에 약수가 없다는 의미이므로 소수.. count plus!
                count++;
            }
        }
        return count; // 최종적으로 주어진 배열에서의 소수 개수 반환!!!

    }
}
