public class First {
    public static void main(String[] args) {
//        System.out.println("Hello");
//        System.out.println("World\n");
//        System.out.println("애국가, 시작!!!!!\n");
//        System.out.println("1절\n동해물과 백두산이 마르고 닳도록\n" +
//                "하느님이 보우하사 우리나라 만세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
//        System.out.println("2절\n남산 위에 저 소나무 철갑을 두른 듯\n" +
//                "바람 서리 불변함은 우리 기상일세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
//        System.out.println("3절\n가을 하늘 공활한데 높고 구름 없이\n" +
//                "밝은 달은 우리 가슴 일편단심일세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
//        System.out.println("4절\n이 기상과 이 맘으로 충성을 다하여\n" +
//                "괴로우나 즐거우나 나라 사랑하세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
        int ten = 10;
//        아래는 자료형 타입별 적절한 명명 예시임.
        int studentAge = 10;
        boolean isDead = true;
        boolean isAlive = false;
        boolean isEating = true;
        boolean eating = true;
        boolean contains = false;
        long earthPeople = 1111111111111111111l;
        char abc ='a';
        double number1 = 1.0;
        double number2 = 0.1;
        if((number2+number1)==1.1){
            System.out.println("Why!?????");
        }
//        위는 자료형 타입별 적절한 명명 예시임.
//       정수형 변수 ten의 초기값이 10이다.
        System.out.println(ten);
//
    }
}
