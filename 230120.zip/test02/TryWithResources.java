package test02;

public class TryWithResources {
    public static void main(String[] args){
        Connection connection = new Connection(); //
        try(connection) { // try 부분에 AutoCloseable을 구현한 객체를 넣어 예외 처리시 자동으로 close()메서드를 호출하도록 설정
            System.out.println("작업 시작");

//            test case1 NumberFormatException

//            String testString1 = "O1O";
//            System.out.println(Integer.parseInt(testString1));

//            test case2 NullPointerException

//            String testString2 = null;
//            System.out.println(testString2.length());

//            test case3 Throwable..

//            String testString[] = new String[3];
//            testString[0] = "가";
//            testString[1] = "나";
//            testString[2] = "다";
//            System.out.println(testString[4]);

        } catch (NullPointerException nullPointerException){
            System.out.println("NPE 발생 !!!!"); // catch의 대상(예외)이 되었을 때 출력 후 finally 실행

        } catch (NumberFormatException numberFormatException){
            System.out.println("NFE 발생 !!!!"); // catch의 대상(예외)이 되었을 때 출력

        } catch (Throwable throwable){ // throws throw catch의 대상이 되는 모든 타입(혹은 객체)의 부모 Class
            System.out.println("그 밖의 오류 발생 !!!!");
        } finally { // 작업 종료 구문 출력 후 종료
            System.out.println("작업 종료");
        }
//        connection.close(); AutoCloseable을 구현한 클래스를 사용하므로 제외
    }
}


class Connection implements AutoCloseable{ // AutoCLoseable 구현한 클래스 Connection 정의
    @Override
    public void close(){ // 메서드 재정의로 실행시킬 close 구문 작성
        System.out.println("leak Prevention!! 커넥션 객체의 연결이 끊어졌습니다.");
    }
}