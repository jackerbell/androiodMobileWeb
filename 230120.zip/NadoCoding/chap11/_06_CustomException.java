package NadoCoding.chap11;

public class _06_CustomException {

}
