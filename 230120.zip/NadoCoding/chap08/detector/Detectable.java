package NadoCoding.chap08.detector;

public interface Detectable {
    void detect(); // 감지

}
