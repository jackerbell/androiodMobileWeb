package NadoCoding.chap08;

import NadoCoding.chap08.camera.FactoryCam;
import NadoCoding.chap08.detector.AdvancedFireDetector;
import NadoCoding.chap08.detector.Detectable;
import NadoCoding.chap08.detector.FireDetector;
import NadoCoding.chap08.reporter.NormalReporter;
import NadoCoding.chap08.reporter.Reportable;
import NadoCoding.chap08.reporter.VideoReporter;

public class _02_interFace {
    // 인터페이스
    // 단일상속 (extends)
    public static void main(String[] args) {
//        NormalReporter normalReporter = new NormalReporter();
        Reportable normalReporter = new NormalReporter(); // 인터페이스를 통해 참조가 가능
        normalReporter.report();

//        VideoReporter videoReporter = new VideoReporter();
        Reportable videoReporter = new VideoReporter();
        videoReporter.report();

        System.out.println("-".repeat(50));
        Detectable fireDetector = new FireDetector();
        fireDetector.detect();

        Detectable advancedFireDetector = new AdvancedFireDetector();

        advancedFireDetector.detect();

        System.out.println("-".repeat(50));

        FactoryCam factoryCam = new FactoryCam();
        factoryCam.setDetector(advancedFireDetector);
        factoryCam.setReportable(videoReporter);

        factoryCam.detect();
        factoryCam.report();

    }
}
