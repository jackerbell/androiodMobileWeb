package NadoCoding.chap08.reporter;

public interface Reportable {
    void report(); // 신고


}
