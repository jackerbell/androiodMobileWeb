package NadoCoding.Chap09.user;

public class VIPUser extends User{
    public VIPUser(String name) {
        super("특별한 "+name);
    }
}
