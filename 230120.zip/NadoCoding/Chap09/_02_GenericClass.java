package NadoCoding.Chap09;

import NadoCoding.Chap09.coffee.*;
import NadoCoding.Chap09.user.User;
import NadoCoding.Chap09.user.VIPUser;

public class _02_GenericClass {
    // 제네릭 클래스

    public static void main(String[] args) {
        CoffeeByNumber c1 = new CoffeeByNumber(33);
        c1.ready();

        CoffeeByNickname c2 = new CoffeeByNickname("유재석");
        c2.ready();

        System.out.println("-".repeat(20));

        CoffeeByName c3 = new CoffeeByName(34);
        c3.ready();
        CoffeeByName c4 = new CoffeeByName("김재환");
        c4.ready();

        System.out.println("-".repeat(20));

//        int c3Name = (int)c3.name; // 이런식으로 해당 객체의 변수를 가져올 때 실수로 잘못된 형변환이 발생될 수 있음.
//        System.out.println("주문 고객 번호: "+c3Name);


        System.out.println("-".repeat(20));

        Coffee<Integer> c5 = new Coffee<>(35); // 하나의 클래스에서 여러 타입의 자료형을 인자로 받아 작업을 처리할 수 있게되었음..
        c5.ready();
        int c5Name = c5.name;
        System.out.println("주문 고객 번호: "+c5Name);

        Coffee<String> c6 = new Coffee<>("조세호");
        c6.ready();
        String c6Name = c6.name;
        System.out.println("주문 고객 번호: "+c6Name);

        System.out.println("-".repeat(20));

        CoffeeByUser<User> c7 = new CoffeeByUser<>(new User("강호동님"));
        c7.ready();

        System.out.println("-".repeat(20));

        CoffeeByUser<User> c8 =new CoffeeByUser<>(new VIPUser("서장훈님"));
        c8.ready();
    }
}
