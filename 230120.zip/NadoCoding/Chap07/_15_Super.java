package NadoCoding.Chap07;

import NadoCoding.Chap07.camera.FactoryCam;
import NadoCoding.Chap07.camera.SpeedCam;

public class _15_Super {
    //super
    public static void main(String[] args) {
        FactoryCam factoryCam = new FactoryCam();
        SpeedCam speedCam = new SpeedCam();

        factoryCam.recordVideo();
        System.out.println("-".repeat(20));
        speedCam.takePicture();
    }
}
