package NadoCoding.Chap07;

import NadoCoding.Chap07.camera.Camera;
import NadoCoding.Chap07.camera.FactoryCam;
import NadoCoding.Chap07.camera.SpeedCam;

public class _12_Inheritance {
    public static void main(String[] args) {
        // 상속
        Camera camera = new Camera();
        FactoryCam factoryCam = new FactoryCam();
        SpeedCam speedCam = new SpeedCam();

        System.out.println(camera.name);
        System.out.println(factoryCam.name);
        System.out.println(speedCam.name);

        System.out.println("-".repeat(30));

        camera.takePicture();
        factoryCam.recordVideo();
        speedCam.takePicture();

        System.out.println("-".repeat(30));

        factoryCam.detectFire();
        speedCam.checkSpeed();
        speedCam.recognizeLicensePlate();

    }
}
