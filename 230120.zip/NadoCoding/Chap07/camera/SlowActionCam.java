package NadoCoding.Chap07.camera;

public class SlowActionCam extends ActionCam {
    public SlowActionCam() {
        this.name = "슬로우 액션 카메라";
    }


}
