package NadoCoding.Chap07.camera;

public class FactoryCam extends Camera { // 자식 클래스

    public FactoryCam(){
        super("공장 카메라");
    }

    @Override
    public void recordVideo() {
        super.recordVideo();
        detectFire();
    }

    public void detectFire() {
        System.out.println("화재를 감시합니다.");
    }

    public void showNameFeature(){
        System.out.println(this.name + "의 주요 기능 : 화재 감지");
    }
}
