package com.kjh.mfp.maple;

import com.kjh.mfp.maple.components.Job;
import com.kjh.mfp.maple.components.Mob;
import com.kjh.mfp.maple.components.MonsterBall;
import com.kjh.mfp.maple.components.Player;
import com.kjh.mfp.maple.components.mobs.OrangeMushroom;
import com.kjh.mfp.maple.components.mobs.RedSnail;
import com.kjh.mfp.maple.components.mobs.Wyvern;
import com.kjh.mfp.maple.components.props.Flyable;
import com.kjh.mfp.maple.components.props.Ridable;

import java.sql.SQLOutput;
import java.util.*;
import java.util.function.IntPredicate;
import java.util.stream.IntStream;

public class Main {
    /*
    *  몹 이름은 완성 한글 1자 이상 10자 이하로만 만들기..
    *
    * */

//    public static final List<Integer> ODD_NUMBERS;
//
//    static { // 프로그램 실행과 동시에 실행되는 정적 생성자
//        System.out.println("정적 생성자");
//        List<Integer> oddNumbers = new ArrayList<>();
//        for (int i = 0; i < 1000; i++) {
//            if(i%2!=0){
//                oddNumbers.add(i);
//            }
//        }
//        ODD_NUMBERS = Collections.unmodifiableList(oddNumbers);
//    }

//    public Main(){
//        System.out.println("객체 생성자");
//    }

    public static  int[] filterEvens(int... nums){
        return Arrays.stream(nums).sorted().filter(x ->x%2==0).toArray();
    }

    public static int[] filterPrimeNumbers(int... nums){
        return  Arrays.stream(nums).sorted().filter(x -> {
            
        }).distinct().toArray();
    }

    //        int[] n = Arrays.copyOfRange(o,1,3);

    public static void main(String[] args) {

//        int[] fixed = filterEvens(new int[] {1,2,3,4,5,6,7,8,9});
//        for (int i: fixed
//             ) {
//            System.out.println(i);
//        }

        int[] fixed2 = filterPrimeNumbers(new int[] {1,2,3,4,5,6,7,8,9,11,14,15});
        for (int i: fixed2
             ) {
            sout
        }


//        int[] nums = {1,3,5,7,9,12,4,2,6,7,8,11,2};
//        Arrays.stream(nums).skip(1).limit(3).forEach(System.out::println);

//        int[] nums = {1,3,5,7,9,12,4,2,6,7,8,11,2};
//        Arrays.stream(nums).distinct().filter(x -> x % 2 == 0).sorted().forEach(System.out::println); // stream[] .. intStrea[] 짝수인것 거르기.. 마지막 forEach는 반환형이 없으므로 더이상 chaining이 불가능함..
//
//        System.out.println("-".repeat(100));
//
//
//        int[] squared = Arrays.stream(nums).map(x -> x * x).toArray();
//        System.out.println(squared);
//        Arrays.stream(squared).forEach(System.out::println);

//        int[] nums = {1,3,5,7,9,12,4,2,6,7,8,11,2};
//        int[] distinctNums = Arrays.stream(nums).distinct().filter(x -> x % 2 == 0).sorted().toArray(); // stream[] .. intStrea[] 짝수인것 거르기..
//        for (int distinctNum: distinctNums) {
//            System.out.println(distinctNum);
//        }

//        int[] nums = {1,3,5,7,9,12,4,2,6,7,8,11,2};
//        int[] distinctNums = Arrays.stream(nums).distinct().sorted().toArray(); // stream[] .. intStrea[] // 중복제거, 오름차순 정렬이  한 번에 처리됨.
//        for (int distinctNum: distinctNums) {
//            System.out.println(distinctNum);
//        }

//        int[] nums = {1,3,5,7,9,12};
//        int[] underTen = Arrays.stream(nums).filter(x -> x < 10).toArray(); // stream[] .. intStrea[]
//        for (int i: underTen) {
//            System.out.println(i);
//        }







//        boolean containEven = Arrays.stream(nums).anyMatch(x -> x % 2 == 0);
//
//
//        IntPredicate intPredicate = new IntPredicate() {
//            @Override
//            public boolean test(int value) {
//                return value % 2 != 0;
//            }
//        };
//
//        boolean onlyOdd4 = Arrays.stream(nums).allMatch(intPredicate);
//
//
//
//        boolean onlyOdd = Arrays.stream(nums).allMatch(x -> x % 2 != 0);
//        boolean containsEven = Arrays.stream(nums).anyMatch(x -> x % 2 == 0);
//        boolean allOdd = Arrays.stream(nums).noneMatch(x -> x % 2 != 0);

//        boolean onlyOdd = true;
//        for (int num: nums) {
//            onlyOdd = false;
//            break;
//        }



//        ArrayList<String> nameList = new ArrayList<>(){{
//           add("김밥");
//           add("라면");
//           add("초밥");
//           add("동해물과백두산!");
//           add("어쩌고");
//           add("ㅋㅋㅋ");
//           add("저쩌고");
//        }};
//
//        for (int size = nameList.size(); size > 0; size--) {
//
//        }
//
//
//        Iterator<String> iterator = nameList.iterator(); // nameList와는 독립적인 별개 처음엔 포인터가 빈 값을 가리킴..
//        while (iterator.hasNext()){ // 다음칸에 값이 포인터가 가리킬 값이 존재하나..
//            String item = iterator.next();
//            if(item.length()>=3){
//                iterator.remove();
//            }
//        }
//        for (String s : nameList) {
//            System.out.println(s);
//        }



//        SortedSet<Integer> nums = new TreeSet<>();  // TreeSet ..
//        nums.add(1);
//        nums.add(7);
//        nums.add(3);
//        nums.add(2);
//        nums.add(6);
//        for (Integer num: nums
//             ) {
//            System.out.println(num); // 자동으로
//        }



//        int[] a = {1,2,3,4,5};
//        IntStream stream = Arrays.stream(a);
//        int sum = stream.sum();
//        System.out.println(sum);


//        int[] a = {1,2,3,4,5};
//        int[] b = {1,3,5,7,9};
//
//        System.out.println(Arrays.mismatch(a,b)); // 잘 쓰지 않은 편



//        int[] a = new int[1000];
//        Arrays.fill(a,1);
//


//        int[] o = {1,2,3,4,5};
//        int[] n = Arrays.copyOfRange(o,1,3);
//        for (int i: n) {
//            System.out.println(i); // index 1~2까지..
//        }


//        boolean[] bs = {true,false,true,false};
//        boolean[] n = Arrays.copyOf(bs,bs.length + 3); // length 이후부터는 기초값인 false로 설정됨..
//        for (boolean b: n) {
//            System.out.println(b);
//        }




//        int[] a = new int[] {1,2,3,4,5};
//        int[] b = new int[] {1,2,3,4,5};
//        int[] d = new int[] {1,2,3,5,4};
//        int[] e = new int[] {1,2,3,4};
//        int[] c = null; // null이 할당되고 new 키워드를 사용했으므로 참조형 객체.. stack에 주소값이 들어감..
//        System.out.println(a==b);
//        System.out.println(Arrays.compare(a,b));
//        System.out.println(Arrays.compare(a,d));
//        System.out.println(Arrays.compare(a,e));



//        String[] fruits = {"Apple","Banana","Carrot"};
//        List<String> fruitList = Arrays.asList(fruits);



//        System.out.println("메인 메서드");
//        new Main();
//        ODD_NUMBERS.add(0,0);
//        System.out.println(ODD_NUMBERS.get(0));

//        HashMap<String, Integer> a = new HashMap<>(){{
//            put("A",1);
//            put("B",2);
//            put("C",3);
//        }};
//
//        for (Map.Entry<String, Integer> entry : a.entrySet()) {
//            System.out.printf("%s : %d\n",entry.getKey(), entry.getValue());
//        }
//
//        Map<String,Map<String,Integer>> studentScoreMap = new HashMap<>(){{
//            put("김",new HashMap<>(){{
//                put("국어",100);
//                put("수학",30);
//                put("영어",100);
//            }});
//            put("이",new HashMap<>(){{
//                put("국어",50);
//                put("수학",100);
//                put("영어",90);
//            }});
//            put("박",new HashMap<>(){{
//                put("국어",10);
//                put("수학",5);
//                put("영어",12);
//            }});
//        }};
//
//        for(Map.Entry<String,Map<String,Integer>> entry : studentScoreMap.entrySet()){
//            System.out.println(entry.getValue());
//        }


//        ArrayList<Integer> list = new ArrayList<>();
//        list.add(13);
//
//        list.remove(0);
//        List<Integer> lockedList = Collections.unmodifiableList(list); // List 객체를 반환 인자의 추가, 삭제 등의 변경이 불가능한 List 객체가 반환됨



////        double d = Main.<Double>printSomething(5D,3D);
//
//        ArrayList<Integer> numList = new ArrayList<>(); // <Integer>부분 생략 가능..
//        Collections.<Integer>addAll(numList,1,2,3,4,5);
//
//        ArrayList<Integer> source = new ArrayList<>(); // <Integer>부분 생략 가능..
////        Collections.<Integer>addAll(source,1,2,3,4,5);
//        Collections.<Integer>addAll(source,1,3,3,5,5,7,1,9);
//        Collections.sort(source, Collections.reverseOrder());
//        Collections.sort(source, Comparator.reverseOrder());
//
//
//        System.out.println(source);
////        System.out.println(Collections.frequency(source,1));  // 같은 것의 개수를 반환
//        Collections.replaceAll(source,1,0);
//        for (Integer integer : source) {
//            System.out.println(integer);
//        }
//        Collections.fill(source, 0);

//
//        ArrayList<Integer> dest = new ArrayList<>(5);
//        Collections.copy(dest,source);
//
//        for (int i = 0; i < 5; i++) {
//            dest.add(null);
//        }
//        for (Integer integer: dest) {
//            System.out.println(integer);
//        }





//
//
//
//        Set<String> keys = studentScoreMap.keySet();
//        double average = 0;
//        for(String key: keys){
//            Set<String> subjects = studentScoreMap.get(key).keySet();
//            System.out.println("--- "+key+" 학생의 성적표 ---");
//            for (String subKey: subjects) {
//                average+= studentScoreMap.get(key).get(subKey);
//                System.out.println(subKey+" : "+studentScoreMap.get(key).get(subKey));
//            }
//            System.out.printf("평균 : %.6f",average/ studentScoreMap.size());
//            System.out.println("\n\n");
//            average=0;
//        }


//        System.out.println(studentScoreMap.get("김").get("수학"));




//        Map<String,Integer> studentHeightMap = new HashMap<>() {{
//            put("김",170);
//            put("이",175);
//            put("박",180);
//            put("최",160);
//        }}; //Map,HashMap은 Interface관계
////        System.out.println(studentHeightMap.get("김"));
////        키는 겹칠 수 없음..
//
////        studentHeightMap.put("최",100);
//
//
//
//        Set<String> keys = studentHeightMap.keySet();
//        for (String key: keys) {
//            System.out.printf(key+"의 키는 "+studentHeightMap.get(key)+"cm이다.\n"); // 순서가 없음..
//        }



//        List<Integer> odds = new ArrayList<>() {{
//           add(1);
//           add(2);
//           add(3);
//        }};

//        NumberList nums = new NumberList();
//        nums.add(1);
//        nums.add(2);
//        nums.add(3);
//        nums.add(4);
//        nums.add(5);
//        System.out.println(nums.sum());
//        System.out.println(nums.average());


//        distinct(new int[] {1,3,1,9,33,5,3,33});


//        ArrayList<Integer> nums = new ArrayList<>();
//        nums.add(1);
//        nums.add(2);
//        nums.add(3);
//
//
//
//        ArrayList<Integer> negatives = new ArrayList<>();
//        negatives.add(-1);
//        negatives.add(-2);
//        negatives.add(-3);
//
//        ArrayList<Integer> positives = new ArrayList<>();
//        positives.add(1);
//        positives.add(2);
//        positives.add(3);
//
//        ArrayList<Integer> numbers = new ArrayList<>();
//        numbers.addAll(positives);
//        numbers.addAll(negatives);
//
//        nums.add(0,0);
//
//        for (Integer num : nums) {
//            System.out.println(num);
//        }


//        ArrayList<Mob> mob = new ArrayList<>(); // 길이가 0인 Mob[]
//        mob.add(new OrangeMushroom()); // 길이가 1
//        mob.add(new RedSnail()); // 길이가 2









//        Stack<Integer> stack = new Stack<>();
//        stack.push(1);
//        stack.push(2);
//        stack.push(3);
//
//        System.out.println(stack.pop());

//        Mob[] mobs = {
//                new OrangeMushroom(),
//                new RedSnail()
//        };
//        Mob mob = new Wyvern();
//
//        mobs = addMob(mobs,mob);
//
//        for (Mob mobFor: mobs) {
//            System.out.println(mobFor.getName());
//        }
        //  주황버섯
        // 빨간달팽이
        // 와이번




//        Triplet<String,String,String> slowpoke_EVTree = new Triplet<>();
//        slowpoke_EVTree.setValueA("야돈");
//        slowpoke_EVTree.setValueB("야도란");
//        slowpoke_EVTree.setValueC("야도킹");
//        System.out.printf("%s의 진화트리는 순서대로 %s(25레벨에 진화) → %s(왕의 징표석을 가지고 통신교환) → %s",slowpoke_EVTree.getValueA(),slowpoke_EVTree.getValueA(),slowpoke_EVTree.getValueB(),slowpoke_EVTree.getValueC());
//
//        Triplet<String,String,Long> nationalInfo = new Triplet<>();
//        nationalInfo.setValueA("대한민국");
//        nationalInfo.setValueB("서울");
//        nationalInfo.setValueC(20000000L);








        // 학생의 이름 - 성적 : String - Integer
        // 지역의 한국어 이름 - 영어 이름 : String - String
        // 가게의 이름 - 오픈 여부 : String - Boolean

//        Tuple<String, Double> studentScore = new Tuple<>();
//         studentScore.setValueA("김학생"); // CTRL P 누르면 무슨 인자 집어넣는지 나옴..
//         studentScore.setValueB(58.7);
//        System.out.printf("%s 학생의 평균은 %.1f점입니다.\n",studentScore.getValueA(),studentScore.getValueB());
//
//         Tuple<String, String> regionName = new Tuple<>();
//         regionName.setValueA("대구");
//         regionName.setValueA("Daegu");
//        System.out.printf("%s(%s) 지역의 여름철 평균 기온...\n",regionName.getValueA(),regionName.getValueB());
//
//         Tuple<String,Boolean> isStoreOpened = new Tuple<>();
//         isStoreOpened.setValueA("맥도날드");
//         isStoreOpened.setValueB(false);
//        System.out.printf("%s는 현재 %s있습니다.\n",isStoreOpened.getValueA(),isStoreOpened.getValueB()?"열려":"닫혀");
//

















//        OrangeMushroom orangeMushroom = new OrangeMushroom();
//        RedSnail redSnail = new RedSnail();
//        Wyvern wyvern = new Wyvern();
//
//        MonsterBall<Wyvern> wyvernMonsterBall = new MonsterBall<>(); // 특정 몬스터만 따로 담기 위해 설정(와이번) 혹은 탑승가능여부.. 비행가능여부..
////        wyvernMonsterBall.setMonster(orangeMushroom);
////        wyvernMonsterBall.setMonster(redSnail);
//        wyvernMonsterBall.setMonster(wyvern);
//
//        MonsterBall<Wyvern> ball1 = new MonsterBall<>();
//        ball1.setMonster(wyvern);
//        MonsterBall<OrangeMushroom> ball2 = new MonsterBall<>();
//        ball2.setMonster(orangeMushroom);
//        System.out.println("ball1과 ball2는 같은 몬스터인가.");
//        System.out.println(ball1.hasSM(ball2));

//        MonsterBall<String> mbs = new MonsterBall<>(); // 잘못된 예시.. T extends Java
//        mbs.setMonster("zz");

//        Wyvern wyvern = new Wyvern();
//        Player player = new Player();
//        player.setName("antiPlayer");
//        player.ride(wyvern);


//        Mob[] mobs = {
//                new OrangeMushroom(),
//                new RedSnail(),
//                new Wyvern()
//        };
//
//        System.out.println("=".repeat(50));
//        for (Mob mob: mobs) {
//            if(mob instanceof Flyable){
//                System.out.println(mob.getName()+"는 날수 있다.");
//            }else{
//                System.out.println(mob.getName()+"는 날수 없다.");
//            }
//
//            System.out.println("=".repeat(50));
//
//            if(mob instanceof Ridable){
//                System.out.println(mob.getName()+"는 탈수 있다.");
//            }else{
//                System.out.println(mob.getName()+"는 탈수 없다.");
//            }
//
//
//        }



//        Wyvern wyvern = new Wyvern();
//        Flyable flyable = wyvern;
//        flyable.fly();










//        Player player = new Player();
//        player.setName("zz궁수zz");
////        player.setJob(Job.PIRATE);
////        player.setJob(Job.BOWMAN);
//        player.setJob(Job.MAGICIAN);
//        player.setJob(Job.THIEF);
//        player.setJob(Job.WARRIOR);
////        player.setJob(Job.전사); // 열거형으로 지정한 Job타입의 객체만 지정할 수 있음!!!!!
//
//
//        Player player2 = new Player();
//        player2.setName("zl랄");
//        player2.setJob(Job.MAGICIAN);
//
//        System.out.println(player.getJob().korean);
//
//        OrangeMushroom orangeMushroom = new OrangeMushroom();
//        player.equals(null);
//        orangeMushroom.equals(null);
//        player.getJob().equals(null);// object를 상속받기에 가능

//        player.getJob().korean = "법사"; . final로 선언하므로 할당은 안됨!





//        Mob m = new Mob("주황버섯");
//        OrangeMushroom om1 = new OrangeMushroom(); // 접근 제한자 public
//        OrangeMushroom o =(OrangeMushroom) om1;
//        o.beCute();
//        RedSnail rs1 = new RedSnail();
////        Mob m = new RedSnail(); // 가능 Mob(부모) 객체의 변수..
//
//        o.attack(rs1);

//          Connection connection = new Connection();
////          try (connection) {
////              String message = "잘 실행함";
////              System.out.println(message);
////          }catch (NullPointerException ex){
////              System.out.println("NPE 오류 터짐");
////          }
//         try (connection) {
//              System.out.println("작업 시작");
//              String message = null;
//              System.out.println(message.length());
//              String message2 = "O1O";
//              System.out.println(Integer.parseInt(message2));
//          }catch (NullPointerException ex){
//              System.out.println("NPE 오류 터짐");
//          } catch (NumberFormatException ex) {
//              System.out.println("NFE 오류 터짐");
//          } finally {
//              System.out.println("작업 종료");
//         }
//
//
////        try{
////            String s = null;
////            s.length();
//////            int i = Integer.parseInt(s);
////        }catch (NumberFormatException ex){ // 선행 오류는 후행 오류보다 자식이어야 한다..
//            System.out.println("올바른 숫자가 아니다.");
//        }catch (NullPointerException ex){
//            System.out.println("무슨 오류인지 모르겟다. ");
//        }catch (Exception ex){
//            System.out.println("무슨 일인지 모르겠다.");
//        }

//        OrangeMushroom om = new OrangeMushroom();
//
//        try{
//            om.attack(om);
//            System.out.println("공격 성공");
//        }catch (Exception ex){
//            System.out.println("??");
//            System.out.println(ex.getMessage()); // 예외처리 메세지 띄우는법
//        }
//        RedSnail rs = new RedSnail();
////        om.move();
////        rs.move();
//
//        Mob[] mobs = {om,rs}; // Mob 클래스 객체화..
//        for (Mob mob: mobs
//             ) {
//            mob.move();
//        }

//        OrangeMushroom om = new OrangeMushroom();
//        om.attack(om);

//        Scanner scanner = new Scanner(System.in);
//        while (true){
//            System.out.print("정수를 입력하세요: ");
//            int n;
//            try{
//                n = scanner.nextInt();
//            }catch (InputMismatchException ex){
//                System.out.println("올바른 정수를 입력해주세요.");
//                continue;
//            }finally {
//                System.out.println("finally 실행됨");
//                scanner.nextLine(); //엔터를 누를 시 계속 예외처리됨으로 이를 방지하기 위해서 선언됨.
//            }
//            double sqrt = Math.sqrt(n);
//            System.out.printf("제곱근은 %f입니다.\n",sqrt);
//
//            scanner.nextLine();
//            System.out.print("계속할까요? (y/n)");
//            String exit = scanner.nextLine();
//            if(!exit.equals("y")){
//                break;
//            }
//        }





//        Mob blueSnail = new Mob("빨간달팽이");
//        blueSnail.name = "BLUE 스네일";
////        blueSnail.setName("BLUE 스네일");
//        blueSnail.sayHello();

//        Mob unknown = new Mob();
//        unknown.sayHello();
//
//        Mob redSnail = new Mob("빨간 달패이");
//        redSnail.sayHello();
//
//        Mob blueSnail = new Mob("블루 스네일");
//
//        Mob orangeMushroom = new Mob("주황버섯"); // 생성자 메서드 호출.. Mob(class Mob) new
//        orangeMushroom.sayHello();
        // Mob(public Mob)

//        Parent p = new Child();
//        p.doSomeThing(); //child 클래스 부가 실행됨..
//
//        Child p2 = new Child();
//        p2.doSomethingParent();
    }

    public static Mob[] addMob(Mob[] mobs,Mob mob){
        // 전달받은 Mob[] 타입의 변수 mobs 배열에 Mob 타입의 매개 변수 mob을 인자로 추가한 새로운 Mob[] 을 반환하는 메섣,.
        Mob[] addMobs = new Mob[mobs.length+1];
        for (int i = 0; i < mobs.length; i++) {
            addMobs[i] = mobs[i];
        }
        addMobs[mobs.length] = mob;
        return addMobs;
    }

    public static Mob[] removeMobAt(Mob[] mobs, int index){
        //전달 받은 Mob 배열인 매개변수 mobs가 가지는 인자 중 그 인덱스 번호가 매개변수 index와 같은 칸을 제거한 새로운 배열을 반환.
        // Mob[] mobs = {om,rs,wv};
        // mobs = removeMobAt{mobs,1}
        // > mobs는 1번째 인자(rs)가 삭제된 {om,wv}이면 됨.
        Mob[] modifiedMobs = new Mob[mobs.length-1];
        int lastIndex=0;
        for (int i = 0; i < mobs.length; i++) {
            if(i!=index){
                modifiedMobs[index++] = mobs[i];
            }
        }
        return modifiedMobs;
    }

    public static List<Integer> filterOdds(int... numbers){
        List<Integer> odds = new ArrayList<>();
        for (int number : numbers) {
            if(number % 2 != 0){
                odds.add(number);
            }
        }
        return odds;
    }

    public static List<Integer> distinct(int... numbers){
        // 전달받은 int[] 타입의 numbers 가 가진 인자 중 겹치는 것을 제외한 인자들만 가지는 새로운 List<Integer>를 반환하세요.
        // distinct(new int[] {1,3,1,9,33,5,3,33}) -> {1,3,9,33,5}  인자를 가지는 List<Integer>
        List<Integer> filtered = new ArrayList<>();
        for (int number : numbers) {
            if(!filtered.contains(numbers)){
                filtered.add(number);
            }
        }
        return filtered;

//        List<Integer> unDuplicatedArray = new ArrayList<>();
//        List<Integer> modifiedArray = new ArrayList<>();
//        int temp[] = new int[numbers.length];
//        for (int number : numbers) {
//            unDuplicatedArray.add(number);
//        }
//        for (int number : numbers) {
//            modifiedArray.add(unDuplicatedArray.get(unDuplicatedArray.indexOf(number)));
//        }
//        return modifiedArray;
    }

//    public static <T extends Number> T void printSomething(T t1, T t2){
//        return t1.hashCode() > t2.hashCode() ? t1 : t2;
//    }
}

//final class Parent{
//     void doSomeThing(){
//        System.out.println("부모가 뭔가 했다.");
//    }
//}
//
//class Child extends Parent{  // 부모에서 final로 선언할 경우 상속받을 수 없음 .. 코드 내에서 최종이기 때문에..
//    @Override
//    void doSomeThing(){
//        System.out.println("자식이 뭔가 했다.");
//    }
//
//    void doSomethingParent(){
//        super.doSomeThing();
//    }
//}


class Tuple<TA,TB> {
    private TA valueA;

    public TA getValueA() {
        return valueA;
    }

    public void setValueA(TA valueA) {
        this.valueA = valueA;
    }

    public TB getValueB() {
        return valueB;
    }

    public void setValueB(TB valueB) {
        this.valueB = valueB;
    }

    private TB valueB;

}

class Triplet<TA,TB,TC>{
    private TA valueA;
    private TB valueB;

    public TA getValueA() {
        return valueA;
    }

    public void setValueA(TA valueA) {
        this.valueA = valueA;
    }

    public TB getValueB() {
        return valueB;
    }

    public void setValueB(TB valueB) {
        this.valueB = valueB;
    }

    public TC getValueC() {
        return valueC;
    }

    public void setValueC(TC valueC) {
        this.valueC = valueC;
    }

    private TC valueC;
}

class Connection implements AutoCloseable {

    @Override
    public void close(){
        System.out.println("커넥션 객체의 연결이 끊어졌다.");
    }
}

class Cube extends Triplet<Integer,Integer,Integer>{
    public Cube(Integer a,Integer b,Integer c) {
        super.setValueA(a);
        super.setValueB(b);
        super.setValueC(c);
    }
    public int getVolume(){
        return this.getValueA()*this.getValueB()*this.getValueC();
    }
}

class NumberList extends ArrayList<Integer>{ // 상속을 받았다.. super, this 활용이 키포인트..

    public int sum(){
        int sum = 0; //멤버변수일 경우 sum실행 후 결과가 저장된 상태로 한 번 더 sum메서드가 진행되어 평균메서드에서 합이 두 배가 됨..
//        Integer[] forSum = (Integer[])super.toArray();
//        for (int s:forSum) {
//            sum += s;
//        }
//        return sum;

        for(int i=0;i<this.size();i++){
//            sum += (int)(super.toArray()[i]); // super.get(i)
            sum += super.get(i);
        }
        return sum;
    }

    public double average(){
        return sum()/ (double) super.size();
//        double average = 0;
//        for (int i = 0; i < this.size(); i++) {
//                average += (int)(super.toArray()[i]);
//        }
//        average /= super.size();
//        return average;
    }
}
