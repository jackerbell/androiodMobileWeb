package com.kjh.mfp.maple.components.props;

public interface Ridable {
    void ride();
}
