package com.kjh.mfp.maple.components;

public class MonsterBall<T extends Mob> { // Type.. 멤버변수의 타입으로 사용가능 Mob이거나 Mob을 상속받아야함..!! 인터페이스 역시 포함됨..
    private T monster;

    public T getMonster() {
        return monster;
    }

    public void setMonster(T monster) {
        this.monster = monster;
    }

    public boolean hasSM(MonsterBall<? extends Mob> a){ // 무작위의 타입이지만 Mob을 상속받는 타입..
       return this.getMonster().getName().equals(a.getMonster().getName()); // 타입은 불명이나 Mob을 상속받기에 getName()호출가능..
    }
}

