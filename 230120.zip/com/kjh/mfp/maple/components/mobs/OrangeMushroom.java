package com.kjh.mfp.maple.components.mobs;

import com.kjh.mfp.maple.components.Mob;
import com.kjh.mfp.maple.components.props.Ridable;

public class OrangeMushroom extends Mob implements Ridable {
    public OrangeMushroom() { //기본 생성자 생략되어있음
        super("주황버섯"); // 부모 생성자 Mob을 가리킴.. 매개변수가 있어야 하므로 내부에 문자열 매개변수 입력..
        System.out.println("주황버섯 다만들었다!");
    }

    public void beCute(){
        System.out.println("주황버섯은 귀여움.");
    }

    @Override
    public void move() { // 추상화되어 있는 메서드를 사용하려는 클래스 내부에서 다시 재정의해서 사용가능.
        System.out.println(this.getName()+"이(가) 뛰어서 이동했다.");
    }

    @Override
    public void ride() {

    }
}
