package com.kjh.mfp.maple.components.mobs;

import com.kjh.mfp.maple.components.Mob;
import com.kjh.mfp.maple.components.props.Flyable;
import com.kjh.mfp.maple.components.props.Ridable;

public class Wyvern extends Mob implements Flyable, Ridable {
    public Wyvern() {
        super("와이번");
    }

    @Override
    public void move() {
        System.out.println(this.getName() + "이/가 움직였다.");
    }

    @Override
    public void fly() {
        System.out.println(this.getName() + "이/가 날았다.");
    }

    @Override
    public void ride() {
        System.out.println(this.getName() + "은/는 탑승 가능하다. ");
    }
}
