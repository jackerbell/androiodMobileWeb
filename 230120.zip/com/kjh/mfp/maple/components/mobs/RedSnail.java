package com.kjh.mfp.maple.components.mobs;

import com.kjh.mfp.maple.components.Mob;

public class RedSnail extends Mob {
    public RedSnail(){
        super("빨간달팽이");
        System.out.println("빨간 달팽이 다만들었다!");
    }

    @Override
    public void move() {
        System.out.println(this.getName() + "이(가) 기어서 이동했다.");
    }
}
