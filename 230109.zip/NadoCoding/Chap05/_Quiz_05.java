package NadoCoding.Chap05;

public class _Quiz_05 {
    public static void main(String[] args) {
        // 배열을 활용 쇼핑몰에서 구매 가능한 신발 사이즈 옵션을 출력하는 프로그램 작성
        // 250부터 295까지 5씩 증가
        // 신발 사이즈 수는 총 10가지


        int[][] size = new int[2][5];
        int sizeAll = 250;
        for (int i = 0; i < size.length; i++) {
            for (int j = 0; j < size[i].length; j++) {
                size[i][j] = sizeAll;
                System.out.println(size[i][j]+" ");
                sizeAll +=5;
            }
            System.out.println();
        }
    }
}
