package com.kjh.mfp;

import com.kjh.mfp.world.Country;

import java.sql.SQLOutput;

public class Main {

    private int someNumber; //멤버 변수..

//    public static int hello = 94; //hello는 접근 제한자가 default 이므로 같은 패키지 경로(com.kjh.mfp)에서만 사용 가능, 사용 가능하게 할려면 public으로 수정!!
    public static void main(String[] args) {
        System.out.println(compress(123456789));
//        double n = 0.0 / 0.0;
//        String result = Double.isNaN(n)?"n은 수가 아님":"n은 수임";
//        System.out.println(result);
//        System.out.println(Double.NaN == Double.NaN); //IEEE 754 .. 자신 포함 NaN의 경우 어떠한 경우에도 동일하다고 보지 않는다.


//        double m = 1/0; // ArithmeticException
//        double n = 1D/0;
//        String result =  n == Double.POSITIVE_INFINITY ? "n은 무한수임." : "n은 무한수가 아님.";
//        System.out.println(result);

//        String s = "1234";
//        String exception = "hello";
//        int i = Integer.parseInt(s) + 1;
//        System.out.println(Integer.parseInt(exception));
//        System.out.println(i);

//          String s=null;
//          System.out.println(s.length());
//          System.out.println(calcCollatz(9));

//        System.out.println(toPascal("Hello World"));
//        System.out.println(toPascal("제 이름은 John Smith 입니다."));
//        System.out.println(toPascal("some weird_name"));
//        System.out.println(toPascal("thisClassName is     Worng"));
//        System.out.println(toPascal("THISenumnameis right"));
//        System.out.println(toPascal("Seoul~Daejeon~Daegu~Busan"));
//         //=> "HelloWorld"
//         //=> "JohnSmith"
//        toPascal("some weird_name"); //=>"SomeWeirdname"
//        toPascal("thisClassName is     Worng");  // => "ThisClassNameIsWorng"
//        toPascal("THISenumnameis right"); // => "ThisenumnameisRight"
//        toPascal("Seoul~Daejeon~Daegu~Busan"); // => "Seouldaejeondaegubusan"
//      1. char와 정수(특히 byte)는 상호 간에 강제 형변환이 가능하다.
//      2. 어떠한 char 정수로 형변환하여 나온 값을 ASCII 코드라고 한다.
//      3. 어떠한 ASCII 코드인 정수를 char 형변환을 하면 어떤 문자가 나온다.
//      4. 대/소문자의 ASCII 코드는 32가 차이난다.
//      5. char와 정수 산순 연산시 정수가 나온다.
//      5. 문자와 문자열 타입은 문자열 합치기 연산(+)이 가능하다.

//      추가 정보
//      1. 문자열 객체가 가지는 toCharArray() 메서드 호출시 문자열 객체가 가지는 문자들을 문자 배열로 반환해준다.
//      2. 문자열 객체가 가지는 charAt(x) 메서드 호출 시 문자열 객체가 가지는 문자 중 x번째 문자를 반환해준다.


//          String helloWorld = "Hello World";
//          System.out.println(helloWorld.charAt(6));
//          char[] helloWorldChars = helloWorld.toCharArray();
//          for(char helloWorldChar : helloWorldChars){
//              System.out.println(helloWorldChar);
//          }

//        char smallA = 'a';
//        char smallB = 'b';
//        char capitalA = 'A';
//        char capitalB = 'B';
//
//        byte smallAByte = (byte) smallA;
//        byte smallBByte = (byte) smallB;
//        byte smallCByte = 99;
//        byte capitalAByte = (byte) capitalA;
//        byte capitalBByte = (byte) capitalB;
//        byte capitalCByte = 67;
//
//        char smallC = (char) smallAByte;
//        char capitalC = (char) capitalCByte;
//
//        System.out.println("small a byte: "+smallAByte);
//        System.out.println("small b byte: "+smallBByte);
//        System.out.println("small c byte: "+smallCByte);
//        System.out.println("capital A byte: "+capitalAByte);
//        System.out.println("capital B byte: "+capitalBByte);
//        System.out.println("capital C byte: "+capitalCByte);
//
//        System.out.println((char)(97-32));

//        System.out.println(sum(7)); //x
//        System.out.println(sum()); //x
//        System.out.println(sum(1,9)); // o
//        System.out.println(sum(5,5,1)); //o
//        System.out.println(sum(5,5,1,12,14)); //o


//        System.out.println(sum(1,2,3,4,5,6,7,8,9,0,1,11,12,13)); // 개수 제한 없이 사용가능..!! 매개 변수를 일반 배열로 선언한 경우 생성자 new를 사용해서 선언해줘야함!! new int[] {1,2,3,4,5,6....}; 위의 형태와 동일한 의미

//        Main main = new Main(); // 비정적 요소에 접근하기 위해 해당 클래스를 객체화한 요소 만들기 정적 요소에서 비정적 요소에 접근하기 위한 유일한 방법임!!!
//        main.someNumber = main.sum(1,3); // 클래스의 멤버이므로 chaning을 통해 접근 가능 ,sum메서드 역시 Main클래스 내부 멤버이므로 ..
//        System.out.println(main.sum(3,7));


          //        int ia = 5; // STACK이라는 메모리 영역에 가진 값.. 기초 타입이 그대로 들어감..
//        int ib = 5;
//        System.out.println(ia == ib); // stack의 값끼리 비교
//
//        String sa2 = new String("abc"); // 다른 주소값을 가지고 싶을 때 직접 생성자 키워드(new)를 사용해 객체화 시킴
//        String sb2 = new String("abc");
//        String sa = "abc"; // 참조타입으로 HEAP 이라는 메모리 영역에 들어감 ,각 문자는 단어 단위로 개별적으로 저장되며 STACK에는 HEAP의 주소값이 저장됨..
//        String sb = "abc";
//        System.out.println(sa == sb); // STACK에 저장된 HEAP의 주소값을 비교.. 이전에 동일한 문자열(문자 조합)이 생성된 경우 그 주소값을 그대로 가지고 쓰기 떄문에 여기서는 같다고 나옴..
//        System.out.println(sa.equals(sb)); // sa의 실제 내용과 sb의 실제 내용이 같은 지 비교할 때 사용!! 여기서 sb는 전달인자.. 직접 함수를 호출할 때 넣어주었음 주의!!
//        System.out.println(sa2 == sb);
//        System.out.println(sa2 == sb2);
//        int age = 94; // 지역 변수..
//        Country korea = new Country(); // 참조타입(대문자) 이후 생성자 키워드로 객체화 (클래스 생성)
//        Country.name = "대한민국";         // 참조타입이므로 각 세개의 변수의 주소값(HEAP)을 STACK의 메모리 영역에 저장
//        korea.population = 51_740_000;
//        korea.area = 100_210D;
//        korea.populationDensity=516.3157369524;
//
//        Country germany = new Country(); // 객체
//        Country.name="독일";
//        germany.population = 83_130_000;
//        germany.area = 357_588D;
//        germany.populationDensity=232.4742441021511;
//
//    //    System.out.println(korea.name+"의 면적당 인구는 "+korea.population/korea.area+"(명/㎢)입니다.");
//    //    System.out.println(germany.name+"의 면적당 인구는 "+germany.population/korea.area+"(명/㎢)입니다.");
//
//        System.out.println(Country.name); //static에서는 잘못된 접근
//        System.out.println(Country.name);
//        System.out.println(Country.name);
    }



//    멤버가 생겨나는 타이밍
//    실행 → (정적 초기화) → main(호출) →
//    public static int sum(int a,int b){
//        return a+b;
//    }
//
//    public static int sum(int a,int b,int c){ //overloading!! 매개 변수의 구조가 반드시 달라야함!!!!!
//        return a+b+c;
//    }
//
//    public static int sum(int a,int b,int c,int d){
//        return a+b+c+d;
//    }
//
//    public static int sum(int a,int b,int c,int d,int e){
//        return a+b+c+d+e; // 꼭 5개의 매개 변수를 모두 활용할 필요는 없음.. 1개만 사용해도 됨.
//    }



//    무작위로 주어진 수들의 합을 구하는 메서드
    public static int sum(int a,int b,int... nums){ //  여기서 nums는 int 배열 타입임 그리고 하나만 존재해야 함.. 다른 매개변수를 받을 수도 있음
            int sum = a+b;
            for(int num :nums) {
                sum += num;
            }
            return sum;
    }

    public static String toPascal(String input){
//        매개 변수 문자열 input이 가지는 값을 파스칼 케이스로 변환하여 반환하는 메서드 toPascal이다.
//        문자열 input이 가지는 모든 문자 중, 영어 알파벳이 아닌 모든 것은 반환하는 값에 포함하지 않는다.
//        문자열 input이 가지는 공백은 단어간 구분자로 인지한다.
//        호출 예:
//        toPascal("Hello World") => "HelloWorld"
//        toPascal("제 이름은 John Smith 입니다.") => "JohnSmith"
//        toPascal("some weird_name") =>"SomeWeirdname"
//        toPascal("thisClassName is     Worng") => "ThisClassNameIsWorng"
//        toPascal("THISenumnameis right") => "ThisenumnameisRight"
//        toPascal("Seoul~Daejeon~Daegu~Busan) => "Seouldaejeondaegubusan"

//        힌트
//        input을 문자 배열(char[])로 변환하여 i를 사용하는 for문을 돌려, 현재 문자가 알파벳이 아닌 경우 생략한다. 문자 번호가 0이거나 바로 전자가 공백()인 경우 현재 문자가 대문자가 아닌 경우 대문자화한다. 문자 번호가 0보다 크고 전자가 공백이 아닌 경우 현재 문자가 소문자가 아닌 경우 소문자화 한다.

        char[] inputToCharArray = input.toCharArray(); // 1. char 배열로 변환..
        char[] compareArray = input.toCharArray(); // input hello     h,e,l,l,o
        String output = "";

//        강사님 답변
        for(int i=0;i< inputToCharArray.length;i++){

            // 2. 현재 첫 자 && 첫자가 소문자일 때 => 그 첫자를 대문자를 만든다.
            // i==0 && (byte)inputToCharArray[i] >= 97 && (byte)inputToCharArray[i] <= 122
            // 1. 가독성 문제, 2. 중복 연산 (byte)inputToCharArray[i]..


            char inputChar = inputToCharArray[i];// 중복연산을 막기 위해
            byte inputCharAscii = (byte) inputChar; // byte 연산 중복으로 인해 한 번더 변수 선언..
            boolean isLower = inputCharAscii >= 97 && inputCharAscii <= 122; // 조건 대신..
            boolean isUpper = inputCharAscii >= 65 && inputCharAscii <= 90;
            if(!isLower && !isUpper){
                continue; // 알파벳이 아닌 경우 그냥 뛰어 넘음..
            }
            if(i==0 && isLower){ // 3. 첫자이고 소문자  조건 간소화.. 가독성 및 연산 작업 간소화
                // 현재 첫번째 글자가 소문자..
                output += (char) (inputCharAscii - 32); //  4. 조건 수행 조건에 부합하는 첫글자 대문자로 변환
            } else if (i==0 && isUpper) { // 4-2 첫자이고 대문자인 경우
                output += inputChar; // 바로 출력에 입력
            } else if (i>0 && isLower){ // 5. 첫자가 아니고 소문자인 경우
                if(inputToCharArray[i-1] == ' '){ // 첫자가 아니고 앞자가 공백..
                    output += (char) (inputCharAscii - 32); // 구분자이므로 대문자로 처리
                } else{
                    // 첫자가 아니고 소문자인데 앞자가 공백이 아닌 경우
                    output += inputChar;
                }
            } else if (i>0 && isUpper) {
                if(inputToCharArray[i-1] == ' '){ // 첫자가 아니고 앞자가 공백..
                    output += inputChar; // 구분자이므로 대문자로 처리
                } else{
                    // 첫자가 아니고 소문자인데 앞자가 공백이 아닌 경우
                    output += (char) (inputCharAscii + 32);
                }
            }
        }

//        System.out.println(output);
        return output;
    }
    public static int calcCollatz(int num){
        // 1  이상의 자연수인 매개변수 num에 대해 콜라츠 추측을 적용하여 몇 번만에 그 수가 1이 될 수 있는지에 대한 값을 반환하는 메서드 calcCollatz 를 완성하세요.
        // 어떠한 수가 짝수이면 2로 나눔
        // 어떠한 수가 홀수이면 3을 곱하고 1을 더한다.
        // 위 절차를 반복한다.
        // 9 28 14 7 22 11 34 17 52 26 13 40 20 10 5 16 8 4 2 1 .. 19회차만에 종료.. 반환값은 19
        // 단, num이 1인 경우 계산활 것이 없음으로 0을 반환한다.
        // 9 19 / 21 7 / 118 33 / 2567 146

//        return num == 1 ? 0 : calcCollatz(num % 2 == 0 ? num / 2 : num * 3 + 1) + 1;

        int count = 0;
        while(num>1){
            if(num%2==0){
                num /= 2;
            } else {
                num = num *3+1;
            }
            count++;
        }
        return count;

    }

    public static int compress(int n){
        //전달바든 10진수인 정수 n을 16 진수로 변환하였을 때 몇 byte를 아낄 수 있는지(길이가 얼마나 짧아지는지) 확인할 수 있는 메서드 compress를 만들기
        // 가령 10진수 123,456,789는 16진수로 75bcd15임으로, 2자리를 아낄 수 있었고, compress(123456789)d의 호출 결과는 2이면 됩니다.
        String hexString = Integer.toHexString(n);
        String tenString = String.valueOf(n);
        return tenString.length() - hexString.length();
    }
}


