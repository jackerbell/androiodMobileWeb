package com.kjh.mfp;

import com.kjh.mfp.Main;

public class Sub {
    public static void main(String[] args) {
//        System.out.println(Main.hello);//멤버 변수

    }
}
