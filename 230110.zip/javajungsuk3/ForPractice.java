package javajungsuk3;

public class ForPractice {
    public static void main(String[] args) {
        int num = 12345;
        int sum = 0;
    }
}
