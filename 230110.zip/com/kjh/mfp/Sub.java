package com.kjh.mfp;

import com.kjh.mfp.Main;

import java.sql.SQLOutput;

public class Sub {
    public static void main(String[] args) {
//        System.out.println(Main.hello);//멤버 변수
        Math.cbrt(27);
        System.out.println(Math.cbrt(27));
        System.out.println(Math.ceil(-24.9));
        System.out.println(Math.cos(0.1));
        System.out.println(Math.random());
        System.out.println(Math.toIntExact(2100000002L));
        System.out.println(Integer.MAX_VALUE);
        System.out.println("");
        System.out.println(Integer.toBinaryString(20000));

    }
}
