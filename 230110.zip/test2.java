public class test2 {
    public static void main(String[] args) {
        System.out.println(getHighLowAvg(new int[] {5,1,3,6,10}));
        System.out.println(getHighLowAvg(new int[] {1,1,11}));
        System.out.println(getHighLowAvg(new int[] {4,4,2,2}));
    }
    public static double getHighLowAvg(int[] numbers){
        int max = 0; //최대값
        int min = numbers[0]; //최소값 처음 인덱스 값으로 초기화
        double avg = 0; //반환할 평균값
        for(int i: numbers){
            max= max <= i ? i : max; // 현재 값이 주어진 배열 요소보다 작거나 같을 경우 배열 요소의 값 할당 아니면 그대로
            min= min <= i ? min : i; // 현재 값이 주어진 배열 요소보다 작거나 같을 그대로 아니면 배열 요소의 값 할당
        }

        avg = ((double) max + min)/2; // 먼저 내부의 덧셈 연산의 결과를 실수형으로 만들어줌.. int형으로만 계산할 시 소수점 빠짐
        return avg;
    }
}
