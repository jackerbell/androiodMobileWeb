public class StringMethodEX {
    public static void main(String[] args) {
        System.out.println(toSentence("  Very  cold  day!  "));
        System.out.println(toSentence("         Out              of sight.    "));
    }


    public static String toSentence(String input) {
        String output = input;
//        while(output.contains("  ")){
//            output = output.strip().replace("  ", " ");
//        }

        return input.contains("  ") ? toSentence(input.replace("  ", " ")) : input; // 강사님 답변, 재귀
                                                                                                    /*
                                                                                                    *
                                                                                                    * */
//        return output;
    }
}
