// let dNum2 = 0.1;
// let  dNum3 = 1.2;
// let isFalseMaybe = Boolean(0.1+1.2==2.2);
// console.log(isFalseMaybe);
// console.log(dNum2+dNum3+false);

// let num = 1;
//
// if(num>=1){
//     console.log("line10 "+num);
// } else if(num>=0){
//     console.log("line12"+num);
// } else{
//     console.log("nothing!!");
// }
//
// console.log("..????");
// script도 동일하게 작동 조건문 중 참이 있을 경우 거기서 종료..