import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class First {
    public static void main(String[] args) {
//        System.out.println("Hello");
//        System.out.println("World\n");
//        System.out.println("애국가, 시작!!!!!\n");
//        System.out.println("1절\n동해물과 백두산이 마르고 닳도록\n" +
//                "하느님이 보우하사 우리나라 만세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
//        System.out.println("2절\n남산 위에 저 소나무 철갑을 두른 듯\n" +
//                "바람 서리 불변함은 우리 기상일세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
//        System.out.println("3절\n가을 하늘 공활한데 높고 구름 없이\n" +
//                "밝은 달은 우리 가슴 일편단심일세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
//        System.out.println("4절\n이 기상과 이 맘으로 충성을 다하여\n" +
//                "괴로우나 즐거우나 나라 사랑하세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
        int ten = 10;
//        아래는 자료형 타입별 적절한 명명 예시임.
        int studentAge = 10;
        boolean isDead = true;
        boolean isAlive = false;
        boolean isEating = true;
        boolean eating = true;
        boolean contains = false;
        long earthPeople = 1111111111111111111l;
        char abc ='a';
        double number1 = 1.0;
        double number2 = 0.1;
        final double pi = 3.14D;

//        System.out.println("이 줄만 주석");
//        for (int i=0;i<100;i++){
//            System.out.println(i);
//        }
//        위의 선언된 상수는 값을 다시 할당할 수 없다.
//        자바에는 순수한 개념의 상수가 아닌 단순히 읽기 값이므로 값을 재할당할 수 없다. (단, 초기값 할당하지 않았을 경우 할당가능!!)
//        상수는 참조타입의 객체일 수 없다... ex) final String name = "김재환"; X
//        System.out.println(pi);


//        if((number2+number1)==1.1){
//            System.out.println("Why!?????");
//        }
//        위는 자료형 타입별 적절한 명명 예시임.
//       정수형 변수 ten의 초기값이 10이다.
//        System.out.println(ten);
//
//        double dNum = 3.0;
//        DecimalFormat form = new DecimalFormat("#.##");
//        System.out.println(form.format(10/dNum));
//        System.out.println(10/dNum);
//        double  dNum2 = 0.1;
//        double  dNum3 = 1.2;
//        if(dNum3+dNum2==2.2){
//            System.out.println("이게 같다고!!???");
//        }

//        System.out.println(11122%2);
//        System.out.println(17%2);

//        boolean isTrue = 10+11>21;
//        참고로 int와 boolean값은 연산 불가..!!
//        System.out.println(isTrue);

//        boolean isTrue = 17 % 2 > 0 == true;
//      1.나머지 2. 비교(초과) 3. 동등 4. 대입 순으로 우선도 적용해 계산
//        System.out.println(isTrue);

//        boolean isTrue = true || false && true || false;
//       1. && 2. || 좌에서 우로
//        System.out.println(isTrue);
//        boolean isFalse = 5 && 6;
//        둘다 int 형이므로 틀린 표현식임 주의!!!!!

//        String eo = 2200 % 2 == 0 ? "짝" : "홀";

//        int num = 17;
//        num *= 2;
//        System.out.println(num);

//        int a = 10;
//        int b = -5;
//        int result = a - -b;
//        1. - 음의 부호 연산자 2. - 산술연산자 3. = 대입연산자 순

//          int num = 0;
//          int num2 = 0;
//          System.out.println(num++);
//          System.out.println(num);
//          System.out.println(++num2);
//          System.out.println(num2);

//        boolean is  = 10 > 5;
//        System.out.println(is);
//        System.out.println(!is);

//        double a =  (double) 5;
//        double b = (double) (10/3);
//        System.out.println(a);
//        System.out.println(b);

//        System.out.println(Math.PI + 1D > 4D);
//        (int) Math.PI
//        1. .객체멤버연산자 2.형변환 연산자

//        System.out.println(1^2);
//       10 01 둘다 자릿수가 다르니까 11

//        int a = 17;
//        int b = 12;
//        int c = 51;
//        double d = 9D;
//        System.out.println((a-b)*(a-b)*(c/b));
//        System.out.println(((int)(a+b-d))*((int)(c/d)));

//        조건문 예시
//        int age = 17;
//        if(age>=20){
//            System.out.println("성인입니다.");
//        }else {
//            System.out.println("미성년입니다.");
//        }

//        int age = 27;
//        if(age>=20){
//            System.out.println("성인입니다.");
////           여기서 참이므로 아래의 조건은 확인하지 않고 조건문을 빠져나감.. 주의!!!!!!!!!!
//        }else if(age >= 0) {
//            System.out.println("태어났습니다.");
//        }

//        int num = 7;
//        if(num==1){
//            System.out.println("일");
//        } else if (num==2) {
//            System.out.println("이");
//        } else if (num==3) {
//            System.out.println("삼");
////      여기서 종료! 아래 구문과 상관없이 조건문 빠져나옴.
//        } else if (num==4) {
//            System.out.println("사");
//        } else if (num==5) {
//            System.out.println("오");
//        } else {
//            System.out.println("모르겠다.");
//        }
//        System.out.println("IF 끝");

//        연습문제
//        int num =0;
//        System.out.println(((num>=0) ? "0이거나 양수입니다.":"음수입니다."));
//        if(num>=0){
//            System.out.println("0이거나 양수입니다.");
//        }else {
//            System.out.println("음수입니다.");
//        }
//        위 정수형 변수 num이 0이상이면 "0이거나 양수입니다." 를, "음수입니다."를 출력하세요.
//        단, 세미콜론은 한 번만 사용합니다.
//        if문에 코드블럭({,})을 생략하지 말 것.


//        if(num>0){
//            if(num%2==1){
//                System.out.println("홀수입니다.");
//            }else {
//                System.out.println("짝수입니다.");
//            }
//        } else if (num==0) {
//            System.out.println("0입니다.");
//        } else {
//            System.out.println("음수입니다.");
//        }




//        위의 정수형 변수 num에 대해 그 값이 음수면 "음수입니다."를 0이면 "0입니다."를, 양의 짝수이면 "짝수입니다."를, 양의 홀수이면 "홀수입니다."를 출력하는 로직을 if문을 사용하여 작성하세요.
//  단 위 변수 num은 동적으로 변하며, 이러한 변화에 능동적으로 대응해야합니다.
//        연습문제

//       조건문 예시

//       반복문예시
//        연습문제1 1~100까지의 자연수 중 홀수들의 합을 구하여 출력하세요.
//        int sum = 0;
//        for(int i=1;i<=100;i++){
//            if(i%2==1){
//                sum+=i;
//            }
//        }
//        System.out.println(sum);

//        연습문제2-1 100부터 1까지의 정수중, 10의 배수인 것만 출력하세요.
//        for(int i=100; i>=1;i--){
//            if(i%10==0){
//                System.out.println("* "+i);
//            }
//        }
//        System.out.println("");
//        연습문제 2-2 반복횟수 50회 이하로 줄이기
//        for(int i=10; i>=1;i--){
//            if(i%10==0){
//                System.out.println("* "+i*10);
//            }
//        }

//        2부터 10000까지 자연수 중 소수(PrimeNumber) 의 개수를 구하시오
//        소수란 어떤 자연수 n을 나누어 떨어질 수 있게할 수 있는 숫자가 1과 n뿐인 수를 의미합니다. 가령 2,3,5,17과 같은 숫자가 있습니다.
//        int count = 0;
//        int count2 = 0; // int i의 약수의 개수,dividerCounter 명명..
//        for(int i=2;i<=10000;i++){
////            10000,10_000 동일 의미
//            for(int j=2;j<=10000;j++){ //2와 10000까지의 숫자와 i와의 숫자 비교용, 10000 대신 i/2..
//                if(i%j==0){ // i의 약수 갯수
//                    count2++;
//                }
//            }
//            if(count2==1){ // i가 본인을 제외한 약수가 없을 경우 소수에 해당하므로 카운트!
////                i/2의 경우 카운트 수가 0이 되어야함
//                count++;
//            }
//            count2=0; // 약수 갯수 초기화
//        }
//        System.out.println(count);


//        강사님 답안
//        int count = 0;
//
//        for(int i=2;i<=10000;i++){
//            boolean isPrime = true;
//            for(int j=2;j<=i/2;j++){ //2와 10000까지의 숫자와 i와의 숫자 비교용, 10000 대신 i/2..
//                if(i%j==0){ // i의 약수 갯수
//                    isPrime = false;
//                    break;
//                }
//            }
//            if(isPrime){
//                count++;
//            }
//        }
//        System.out.println(count);
//        반복문예시

//        for(int i=1;i<=10;i++){
//            if(i%2==0){
////                break;
//                continue;
//            }
//            System.out.println(i);
//        }

//        int num =3;
////        break가 없고 1인 경우 1,2,3,default 모두 실행됨...
//        switch (num){
//            case 1:
//                System.out.println("일");
//                break;
//            case 2:
//                System.out.println("이");
//                break;
//            case 3:
//                System.out.println("삼");
//                break;
//            default:
//                System.out.println("모르겠다.");
//        }

//        String 목적지 = "대전";
//
//        switch (목적지){
//            case "부산":
//                System.out.println("부산 만났었음");
//            case "대구":
//                System.out.println("대구 만났었음");
//            case "대전":
//                System.out.println("대전 만났었음");
//        }


//        boolean isFalse = false;
////        while (isFalse){
////            System.out.println("while 실행 됨");
////        }
//
//        do {
//            System.out.println("do-while 실행됨");
//        } while (isFalse);

//        System.out.println("나는 "+25); // 결과는 문자열로 통일!!
//        int[] odds = {1,3,5,7,9};
//        //            0 1 2 3 4 index Number
//        for (int odd : odds) {
//            //    0 ~ 4 < 5(odds.length)
//            System.out.println(odd);
//        }

//        String[] students = {"A","B","C","D","E"};
//        for(int i=0; i<students.length;i++){
//            System.out.println((i+1) + "번 학생" + students[i]);
//        }

//        int[] numbers = {10,9,8,7,6,5,4,3,2,1};
//        int[] odds ;
//        int oddCount = 0; // numbers 요소 중 홀수의 개수
//
//        for(int number : numbers){
//            if(number%2==1){
//                oddCount++;
//            }
//        }
//
//        odds = new int[oddCount]; //5
//        int oddIndex = 0;
//        for(int i = numbers.length-1;i>=0;i--){
//            if(numbers[i]%2==1){
//                odds[oddIndex++] = numbers[i];
//            }
//        }
//
//        for (int odd : odds){
//            System.out.println(odd);
//        }

//        int[] numbers = {1,11,3,8,5,6,99,108};
//        int[] evens;
//        int[] odds;
//
//        int evensCount = 0;
//        int oddsCount = 0;
//
//        int shuffle = 0;
////
//        for(int i =0;i<numbers.length;i++){ // 순서 정렬용..
//            for(int j = i+1;j<numbers.length;j++){
//                if(numbers[i]>numbers[j]){
//                    shuffle = numbers[i];
//                    numbers[i] = numbers[j];
//                    numbers[j] = shuffle;
//                }
//            }
//        }
//        System.out.println(numbers);
//        System.out.println(Arrays.toString(numbers)); // 그냥 하면 객체? 취급이어서????
//
////
//
//
//        for(int number : numbers){
//            if(number%2==0){
//                evensCount++;
//            }else {
//                oddsCount++;
//            }
//        }
//
//        evens = new int[evensCount];
//        odds = new int[oddsCount];
//
//        int evenIndex = 0;
//        int oddIndex = 0;
//
//        for(int i =0;i<numbers.length;i++){
//            if(numbers[i]%2==0){
//                evens[evenIndex] = numbers[i];
//                evenIndex++;
//            }else{
//                odds[oddIndex] = numbers[i];
//                oddIndex++;
//            }
//        }
//
//        System.out.println("짝수 출력");
//        for(int even : evens){
//            System.out.println(even);
//        }
//        System.out.println("---------------");
//        System.out.println("홀수 출력");
//        for(int odd : odds){
//            System.out.println(odd);
//        }

//        강사님 답변...
//        int[] evenss = Arrays.stream(numbers).filter(x -> x %2==0).toArray();
//        int[] oddss = Arrays.stream(numbers).filter(x -> x %2!=0).toArray();
//        System.out.println(Arrays.toString(evenss));
//        System.out.println(Arrays.toString(oddss));
//        stream API  .. 보고 원리 이해할 수 있도록 하기... 선언, 가공, 반환 순으로 진행

//        System.out.println(getMin(3,7));// 내부 args 전달인자
//        System.out.println(getMax(1,2));
//        System.out.println(getAbs(3));
//        System.out.println(getPow(16,8));
          System.out.println(getHighEST(new int[] {1,10,4,-1,0,6,13,91,11}));
          System.out.println(getHighEST(new int[] {0}));
          System.out.println(getHighEST(new int[] {-167, -13, -1, -55, -103}));
          System.out.println("");
          System.out.println(getSmallEST(new int[] {1,10,4,-1,0,6,13,91,11}));
          System.out.println(getSmallEST(new int[] {0}));
          System.out.println(getSmallEST(new int[] {-167, -13, -1, -55, -103}));
        System.out.println("");
        System.out.println(getAvg(new double[] {1,3,5}));
        System.out.println(getAvg(new double[] {10,90}));

    }
//    public static int getMin(int a,int b){ // 매개변수
//        return a<=b?a:b; //크기가 같을 경우 a 출력으로 예외 처리
//    }
//
//    public static int getMax(int num1,int num2){
//        if(num1!=num2){
//            return num1>num2?num1:num2;
//        }else {
//            return num1-num2;// 똑같다는 의미를 정수형으로 명확하게 표현하기 위해 동일한 크기의 인자 둘을 뺀 값(0)을 출력
//        }
//    }
//
//    public static int getAbs(int a,int b){
//        return a<0?-a:a;
//    }
//
//    public static long getPow(long num1,long num2){
//        long powNum = 1;
//        for(long i=1;i<=num2;i++){
//            powNum *= num1;
//        }
//        return powNum;
//    }
//    Integer.MAX_VALUE: 정수형(int) 최대값
//    Integer.MIN_VALUE: 정수형(int) 최소값

    public static int getHighEST(int[] nums){
        int highNum = 0;
        for(int i =1;i<nums.length;i++){
            if(i==1){
                highNum = nums[i-1]>nums[i]?nums[i-1]:nums[i];
            }
            else{
                highNum = highNum>nums[i]?highNum:nums[i];
            }
        }
        return highNum;
    }

    public static int getSmallEST(int[] nums){
        int smallNum = 0;
        for(int i =1;i<nums.length;i++){
            if(i==1){
                smallNum = nums[i-1]<nums[i]?nums[i-1]:nums[i];
            }
            else{
                smallNum = smallNum<nums[i]?smallNum:nums[i];
            }
        }
        return smallNum;
    }

    public static double getAvg(double[] nums){
        double avg=0;
        for(double i : nums){
            avg+=i/nums.length; // a/num.length + b/num.length + c/num.length + d/num.length + e/num.length  or (a+b+c+d+e)/num.length
        }
        return avg;
    }

    public static int getFibonacci(){
        int num1=1;
        int num2=1;
        return 0;
    }

}


