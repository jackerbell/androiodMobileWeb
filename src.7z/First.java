import java.text.DecimalFormat;

public class First {
    public static void main(String[] args) {
//        System.out.println("Hello");
//        System.out.println("World\n");
//        System.out.println("애국가, 시작!!!!!\n");
//        System.out.println("1절\n동해물과 백두산이 마르고 닳도록\n" +
//                "하느님이 보우하사 우리나라 만세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
//        System.out.println("2절\n남산 위에 저 소나무 철갑을 두른 듯\n" +
//                "바람 서리 불변함은 우리 기상일세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
//        System.out.println("3절\n가을 하늘 공활한데 높고 구름 없이\n" +
//                "밝은 달은 우리 가슴 일편단심일세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
//        System.out.println("4절\n이 기상과 이 맘으로 충성을 다하여\n" +
//                "괴로우나 즐거우나 나라 사랑하세\n" +
//                "무궁화 삼천리 화려 강산\n" +
//                "대한 사람 대한으로 길이 보전하세\n");
        int ten = 10;
//        아래는 자료형 타입별 적절한 명명 예시임.
        int studentAge = 10;
        boolean isDead = true;
        boolean isAlive = false;
        boolean isEating = true;
        boolean eating = true;
        boolean contains = false;
        long earthPeople = 1111111111111111111l;
        char abc ='a';
        double number1 = 1.0;
        double number2 = 0.1;
        final double pi = 3.14D;

//        System.out.println("이 줄만 주석");
//        for (int i=0;i<100;i++){
//            System.out.println(i);
//        }
//        위의 선언된 상수는 값을 다시 할당할 수 없다.
//        자바에는 순수한 개념의 상수가 아닌 단순히 읽기 값이므로 값을 재할당할 수 없다. (단, 초기값 할당하지 않았을 경우 할당가능!!)
//        상수는 참조타입의 객체일 수 없다... ex) final String name = "김재환"; X
//        System.out.println(pi);


//        if((number2+number1)==1.1){
//            System.out.println("Why!?????");
//        }
//        위는 자료형 타입별 적절한 명명 예시임.
//       정수형 변수 ten의 초기값이 10이다.
//        System.out.println(ten);
//
//        double dNum = 3.0;
//        DecimalFormat form = new DecimalFormat("#.##");
//        System.out.println(form.format(10/dNum));
//        System.out.println(10/dNum);
//        double  dNum2 = 0.1;
//        double  dNum3 = 1.2;
//        if(dNum3+dNum2==2.2){
//            System.out.println("이게 같다고!!???");
//        }

//        System.out.println(11122%2);
//        System.out.println(17%2);

//        boolean isTrue = 10+11>21;
//        참고로 int와 boolean값은 연산 불가..!!
//        System.out.println(isTrue);

//        boolean isTrue = 17 % 2 > 0 == true;
//      1.나머지 2. 비교(초과) 3. 동등 4. 대입 순으로 우선도 적용해 계산
//        System.out.println(isTrue);

//        boolean isTrue = true || false && true || false;
//       1. && 2. || 좌에서 우로
//        System.out.println(isTrue);
//        boolean isFalse = 5 && 6;
//        둘다 int 형이므로 틀린 표현식임 주의!!!!!

//        String eo = 2200 % 2 == 0 ? "짝" : "홀";

//        int num = 17;
//        num *= 2;
//        System.out.println(num);

//        int a = 10;
//        int b = -5;
//        int result = a - -b;
//        1. - 음의 부호 연산자 2. - 산술연산자 3. = 대입연산자 순

//          int num = 0;
//          int num2 = 0;
//          System.out.println(num++);
//          System.out.println(num);
//          System.out.println(++num2);
//          System.out.println(num2);

//        boolean is  = 10 > 5;
//        System.out.println(is);
//        System.out.println(!is);

//        double a =  (double) 5;
//        double b = (double) (10/3);
//        System.out.println(a);
//        System.out.println(b);

//        System.out.println(Math.PI + 1D > 4D);
//        (int) Math.PI
//        1. .객체멤버연산자 2.형변환 연산자

//        System.out.println(1^2);
//       10 01 둘다 자릿수가 다르니까 11

        int a = 17;
        int b = 12;
        int c = 51;
        double d = 9D;
        System.out.println((a-b)*(a-b)*(c/b));
        System.out.println(((int)(a+b-d))*((int)(c/d)));

    }
}


