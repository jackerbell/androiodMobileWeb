let dNum2 = 0.1;
let  dNum3 = 1.2;
let isFalseMaybe = Boolean(0.1+1.2==2.2);
console.log(isFalseMaybe);
console.log(dNum2+dNum3+false);