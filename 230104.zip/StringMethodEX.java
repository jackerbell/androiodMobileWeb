public class StringMethodEX {
    public static void main(String[] args) {
        System.out.println(toSentence("  Very  cold  day!  "));
        System.out.println(toSentence("         Out              of sight.    "));
    }


    public static String toSentence(String input) {
        String output = input;
        while(output.contains("  ")){
            output = output.strip().replace("  ", " ");
        }
        // 전달바든 문자열 input의 앞, 뒤 공백을 모두 제거
        // 전달받은 문자열 input이 가지는 모든 2개 이상의 연속된 공백을 1개로 치환한다.
        // 위 결과 값을 반환한다.
        // ex toSentence(" Very cold day!  ") // -> "Very cold day!"
        //
        // toSentence("Out              of sight.   "); // -> "Out of sight."
        return output;
    }

//    public static String toPascal(String input){
//        input = input.strip().replaceAll("[a-zA-Z]]", "").toLowerCase();
//        String[] inputArray = input.split(" ");
//        String output = "";
//        for (String s: inputArray){
//            output += (char) (s.charAt(0) -32) + (s.length() > 1? s.substring(1,s.length()),"");
//        }
//    }
}
