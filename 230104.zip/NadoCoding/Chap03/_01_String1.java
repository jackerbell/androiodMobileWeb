package NadoCoding.Chap03;

public  class _01_String1 {
    public static String output="";
    public static void main(String[] args) {

        System.out.print(solution("가"));// 빈 값일 경우 개행을 안하고 출력
        System.out.print(solution("나"));
        System.out.print(solution("다라"));
        System.out.print(solution("마"));
        System.out.print(solution("바사"));
        System.out.print(solution("아자차카"));
        System.out.print(solution("파"));
        System.out.print(solution("타"));
        System.out.print(solution("하"));
        System.out.print(solution());
    }
    // 문자열 연속으로 호출하기
    // 토종이는 연속적으로 문자열을 인자로 넣고 마지막에 빈 인자`()`를 호출하면 문자열을 누적으로 반환해주는 ㅎ마수를 만들고 싶습니다.
    // 연속적으로 문자열을 인자로 입력받고 빈 인자() 호출 시, 누락된 문자열을 반환하는 함수 solution을 작성해주세요
    // 결과: hello world!
    // solution('hello')('world')();
    // 결과: 가 나 다라 마 바사 아자차카 파 타 하
    // solution('가')('나')('다라')('마')('바사')('아자차카')('파')('타')('하')

    public static String solution(String... input){

        for(String s: input){
            output += s+" ";
        }
        return (input.length==0)?output:"";
    }

    // solution 함수는 첫 번쨰 인자로 문자열의 배열을 받습니다.
    // 문자열 .은 현재 경로를 나타냅니다.
    // 문자열 .. 은 부보 경로를 나타냅니다.
    // 특별한 문자열 ... 은 조부모 경로를 나타냅니다.
    // 입력으로 들어온 파일 경로들을 연결하여 . .. ...가 없는 형태로 반환해야합니다.
    // 문자열 배열이 비어 있는 경우는 고려하지 않습니다.
    // 문자열 배열의 첫번째 원소는 항상 / 로 시작합니다.
    // solution['.','foo'] 와 같이 상대 경로로 시작하는 경우는 고려하지 않습니다.
    // . .. ... 이 문자열의 중간에 올 수 있습니다.
    // e.g. solution(['/foo/bar/../baz', 'quux']) === '/foo/baz/quux
    public static String solution2(String... input){
        for(String s:input){
            output += s.concat("/");
        }
        return "";
    }
}
