package com.kjh.mfp.world;

public class Country {
    public static String name = null; // 문자열의 경우 null(비어 있음)인 상태..
    // static을 붙여 정적인 변수로 바꿈.. 프로그램 실행과 동시에 등록됨(최우선적으로 등록!).. 프로그램 내 유일한 형태이므로 결과적으로 Country.name을 가리킨다. 따라서 다른 값을 할당하면 먼저 선언한 다른 변수의 값도 바뀌게 됨..
    public int population; // 아무 값도 할당하지 않았으므로 0인 상태..
    public double area; // 0D로 초기화

    public double populationDensity;
}
