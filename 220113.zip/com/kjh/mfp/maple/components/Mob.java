package com.kjh.mfp.maple.components;

import com.kjh.mfp.maple.components.mobs.OrangeMushroom;

public abstract class Mob {
    private String name; //


    //    public Mob(){
//        this("이름없음");
//    }
//
    protected Mob(String name) {
        super(); // 생략해도 됨.. 당연히 있는걸로 치부.. 부모 생성자 호출.. 반드시 this,super 둘 중하나로 구문시작하는 것에 유의!!!
        this.setName(name); //Mob.setName
        // public String name = String name(매개 변수) 정적멤버에 접근 불가..
        // this.blah ..  정적요소에 비정적 요소로 접근한 잘못된 예시.
        // Mob.name      name이 비정적인데 정적으로 접근한 잘못된 예시.
        System.out.println(name + "이(가) 생성됨.");
    }

    public String getName() { // alt+insert getter,setter ...  자동생성..
        return name;
    }

    public void setName(String name) {
        if (!name.matches("^([가-힣]{1,10})$")) {//
            throw new RuntimeException("이름 제대로 지어라.");
        }
        this.name = name;
    }

    public void sayHello() {
        System.out.printf("%s이(가) 인사합니다.!\n", this.name); //비정적 멤버변수에 접근시에는 this 붙이기!!
    }

    public void attack(Mob m) throws Exception {
        if (this == m) {
            throw new Exception("자살할 수 없다."); // 연속적으로 throw선언 불가..
        }
        System.out.printf("%s가 %s를 공격했다.", this.name, m.name);
        if (m instanceof OrangeMushroom) { // OR로 형변환해도 가능한가??
            System.out.println("불쌍한 주황버섯을 공격했다.");
        }
    }

    public abstract void move();

}
