package com.kjh.mfp.maple;

import com.kjh.mfp.maple.components.Mob;
import com.kjh.mfp.maple.components.mobs.OrangeMushroom;
import com.kjh.mfp.maple.components.mobs.RedSnail;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    /*
    *  몹 이름은 완성 한글 1자 이상 10자 이하로만 만들기..
    *
    * */
    public static void main(String[] args) {
//        Mob m = new Mob("주황버섯");
//        OrangeMushroom om1 = new OrangeMushroom(); // 접근 제한자 public
//        OrangeMushroom o =(OrangeMushroom) om1;
//        o.beCute();
//        RedSnail rs1 = new RedSnail();
////        Mob m = new RedSnail(); // 가능 Mob(부모) 객체의 변수..
//
//        o.attack(rs1);

          Connection connection = new Connection();
//          try (connection) {
//              String message = "잘 실행함";
//              System.out.println(message);
//          }catch (NullPointerException ex){
//              System.out.println("NPE 오류 터짐");
//          }
         try (connection) {
              String message = null;
              System.out.println(message.length());
          }catch (NullPointerException ex){
              System.out.println("NPE 오류 터짐");
          }finally {
             String a = null;
             a.length();
             connection.close();
         }


//        try{
//            String s = null;
//            s.length();
////            int i = Integer.parseInt(s);
//        }catch (NumberFormatException ex){ // 선행 오류는 후행 오류보다 자식이어야 한다..
//            System.out.println("올바른 숫자가 아니다.");
//        }catch (NullPointerException ex){
//            System.out.println("무슨 오류인지 모르겟다. ");
//        }catch (Exception ex){
//            System.out.println("무슨 일인지 모르겠다.");
//        }

//        OrangeMushroom om = new OrangeMushroom();
//
//        try{
//            om.attack(om);
//            System.out.println("공격 성공");
//        }catch (Exception ex){
//            System.out.println("??");
//            System.out.println(ex.getMessage()); // 예외처리 메세지 띄우는법
//        }
//        RedSnail rs = new RedSnail();
////        om.move();
////        rs.move();
//
//        Mob[] mobs = {om,rs}; // Mob 클래스 객체화..
//        for (Mob mob: mobs
//             ) {
//            mob.move();
//        }

//        OrangeMushroom om = new OrangeMushroom();
//        om.attack(om);

//        Scanner scanner = new Scanner(System.in);
//        while (true){
//            System.out.print("정수를 입력하세요: ");
//            int n;
//            try{
//                n = scanner.nextInt();
//            }catch (InputMismatchException ex){
//                System.out.println("올바른 정수를 입력해주세요.");
//                continue;
//            }finally {
//                System.out.println("finally 실행됨");
//                scanner.nextLine(); //엔터를 누를 시 계속 예외처리됨으로 이를 방지하기 위해서 선언됨.
//            }
//            double sqrt = Math.sqrt(n);
//            System.out.printf("제곱근은 %f입니다.\n",sqrt);
//
//            scanner.nextLine();
//            System.out.print("계속할까요? (y/n)");
//            String exit = scanner.nextLine();
//            if(!exit.equals("y")){
//                break;
//            }
//        }





//        Mob blueSnail = new Mob("빨간달팽이");
//        blueSnail.name = "BLUE 스네일";
////        blueSnail.setName("BLUE 스네일");
//        blueSnail.sayHello();

//        Mob unknown = new Mob();
//        unknown.sayHello();
//
//        Mob redSnail = new Mob("빨간 달패이");
//        redSnail.sayHello();
//
//        Mob blueSnail = new Mob("블루 스네일");
//
//        Mob orangeMushroom = new Mob("주황버섯"); // 생성자 메서드 호출.. Mob(class Mob) new
//        orangeMushroom.sayHello();
        // Mob(public Mob)

//        Parent p = new Child();
//        p.doSomeThing(); //child 클래스 부가 실행됨..
//
//        Child p2 = new Child();
//        p2.doSomethingParent();
    }
}

//final class Parent{
//     void doSomeThing(){
//        System.out.println("부모가 뭔가 했다.");
//    }
//}
//
//class Child extends Parent{  // 부모에서 final로 선언할 경우 상속받을 수 없음 .. 코드 내에서 최종이기 때문에..
//    @Override
//    void doSomeThing(){
//        System.out.println("자식이 뭔가 했다.");
//    }
//
//    void doSomethingParent(){
//        super.doSomeThing();
//    }
//}

class Connection implements AutoCloseable {

    @Override
    public void close(){
        System.out.println("커넥션 객체의 연결이 끊어졌다.");
    }
}
