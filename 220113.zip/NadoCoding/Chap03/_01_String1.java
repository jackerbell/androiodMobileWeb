package NadoCoding.Chap03;

import javax.naming.NameNotFoundException;
import java.text.SimpleDateFormat;
import java.util.Date;

public  class _01_String1 {
    public static void main(String[] args) {

//        double pi = 3.14D;
//        int population = 51_439_038;
////        System.out.println(String.format("%-4d명,%2d명,%3d명,%4d명",17,3,115,1955));
////        System.out.println(String.format("%3$03d명,%<04d,%<05d,%<05d",17,3,115,1955)); // < 직전에 썼던 인자($)
////        System.out.println(String.format("%4$d명,%2d명,%3d명,%4d명",17,3,115,1955)); // 0번부터 시작하지 않고, 순서를 지정하지 않고 나열된 순서대로 가져오므로 순서에 영향 x
////        System.out.println(String.format("%,d",population)); // 1000단위마다 구분..
//        System.out.println(String.format("%o",100));
//        System.out.println(String.format("%,-5d",10000000));
//
//        System.out.println(String.format("%.3f",3.1414142424));
//        System.out.println(String.format("%e",314.14142424112312321321D));

        Date date = new Date();
        String formattedDate2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date); // new, ! 우선순위랑 관계 없이 반드시 먼저 연산 이후 연산순으로 동작.. 고로 생성자 키워드로 불러온 객체를 통해 접근할 수 있으므로 비정적..
        System.out.println(formattedDate2);
        // "%tY-%"
//        System.out.println(myDate);
//        String formattedDateY = String.format("%tY",myDate);
//        String formattedDatem = String.format("%tm",myDate);
//        String formattedDated = String.format("%tD",myDate);
//        System.out.println(formattedDateY);
//        System.out.println(formattedDatem);
//        System.out.println(formattedDated);



//        System.out.println(String.format("인증번호: %06d",5511));
//
//        // 문자열로 바꾸는 방법들..
//        String piStr1 = pi + "";
//        String piStr2 = String.valueOf(pi);
//
//        String message = String.format("대구광역시 중구 중앙대로 %d %d층",366,10);
//        System.out.println(message);
        // 대구광역시 중구 중앙대로 366 10층
    }

    public static String printRRN(String r) {
        String result = "";
        result = r.substring(0,8);
        return result;
    }

}
