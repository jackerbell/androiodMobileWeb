package NadoCoding.Chap07;

public class _04_Method {
    public static void main(String[] args) {
        BlackBox b1 = new BlackBox();
        b1.modelName = "까망이";

        System.out.println("---------------------------");
        b1.canAutoReport = true;
        b1.autoReport();

        b1.insertMemoryCard(256);
        int fileCount = b1.getVideoGetCount(2);
        System.out.println("일반 영상 파일 수 : " + fileCount);

    }
}
