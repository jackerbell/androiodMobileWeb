package com.kjh.mfp.maple;

import com.kjh.mfp.maple.components.Mob;
import com.kjh.mfp.maple.components.mobs.OrangeMushroom;
import com.kjh.mfp.maple.components.mobs.RedSnail;

public class Main {
    /*
    *  몹 이름은 완성 한글 1자 이상 10자 이하로만 만들기..
    *
    * */
    public static void main(String[] args) {
//        Mob m = new Mob("주황버섯");
        OrangeMushroom om1 = new OrangeMushroom(); // 접근 제한자 public
        OrangeMushroom o =(OrangeMushroom) om1;
        o.beCute();
        RedSnail rs1 = new RedSnail();
//        Mob m = new RedSnail(); // 가능 Mob(부모) 객체의 변수..

        o.attack(rs1);





//        Mob blueSnail = new Mob("빨간달팽이");
//        blueSnail.name = "BLUE 스네일";
////        blueSnail.setName("BLUE 스네일");
//        blueSnail.sayHello();

//        Mob unknown = new Mob();
//        unknown.sayHello();
//
//        Mob redSnail = new Mob("빨간 달패이");
//        redSnail.sayHello();
//
//        Mob blueSnail = new Mob("블루 스네일");
//
//        Mob orangeMushroom = new Mob("주황버섯"); // 생성자 메서드 호출.. Mob(class Mob) new
//        orangeMushroom.sayHello();
        // Mob(public Mob)


    }
}
