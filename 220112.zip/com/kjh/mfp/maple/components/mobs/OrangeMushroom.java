package com.kjh.mfp.maple.components.mobs;

import com.kjh.mfp.maple.components.Mob;

public class OrangeMushroom extends Mob {
    public OrangeMushroom() { //기본 생성자 생략되어있음
        super("주황버섯"); // 부모 생성자 Mob을 가리킴.. 매개변수가 있어야 하므로 내부에 문자열 매개변수 입력..
        System.out.println("주황버섯 다만들었다!");
    }

    public void beCute(){
        System.out.println("주황버섯은 귀여움.");
    }


}
