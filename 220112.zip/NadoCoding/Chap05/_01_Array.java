package NadoCoding.Chap05;

public class _01_Array {
    String[] coffees = new String[4];
    String Coffees[] = new String[4];

}
