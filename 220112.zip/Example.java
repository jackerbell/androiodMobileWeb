public class Example {
    public static void main(String[] args) {
        String[] babbling = { "aya", "ye", "woo", "ma"};
        String[] babblingGathering;
        
    }
}
