public class FunctionExample {
    public static void main(String[] args) {
        sayHello();
        sayHelloTo("chicken");
        printSum(3,5);
        int result = sum(3,2);
        System.out.println(result);
        int[] multiplySomething = addAndMultiply(3,5);
        System.out.println(multiplySomething[0]);
        System.out.println(multiplySomething[1]);
        sayHola("바보");
    }

    public static void sayHola(String name){
        if(name.equals("바보")){
            System.out.println("바른말 고운 말을 사용해주세요.");
            return;
        }
        else {
            System.out.println(name + "님, 안녕하세요?");
        }
    }

    public static int[] addAndMultiply(int a, int b){
        int sum = a+b;
        int product = a*b;
        int[] result = {sum,product};
        return result;
    }

    public static int sum(int a,int b){
        return a+b;
    }
    public static void  printSum(int a,int b){
        System.out.println(String.format("%d + %d = %d",a,b,a+b));
    }
    public static void  sayHelloTo(String name){
        System.out.println("Hello, "+name);
    }
    public static void sayHello(){
        System.out.println("Hello.");
    }
}
